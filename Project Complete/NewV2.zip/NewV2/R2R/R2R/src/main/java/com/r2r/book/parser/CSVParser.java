package com.r2r.book.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.CsvToBean;
import au.com.bytecode.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;

import com.r2r.book.model.Book;

public class CSVParser {

	public List <Book> parseToBooks(String fileName) throws IOException{
		
		CSVReader reader = new CSVReader(new FileReader(fileName), ',');
         
        List<Book> bookList = new ArrayList<Book>();
        
        String[] record = null;
        
        reader.readNext();
        
        while((record = reader.readNext()) != null){
        	Book book = new Book();
        	book.setBookId(Integer.parseInt(record[0]));
        	book.setTitle(record[1]);
        	book.setIsbn(record[2]);
        	book.setDescription(record[3]);
        	book.setRating(new BigDecimal(record[4]));
        	book.setAuthor(record[5]);
        	book.setImage(record[6]);
        	book.setGenre(record[7]);
        	book.setPublishedOn(record[8]);
        	book.setPublisher(record[9]);
        	book.setStatus(Boolean.parseBoolean(record[10]));
        	bookList.add(book);
        }
        return bookList;
	}
}
