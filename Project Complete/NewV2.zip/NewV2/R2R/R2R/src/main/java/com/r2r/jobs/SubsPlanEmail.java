package com.r2r.jobs;

import java.math.BigInteger;
import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.r2r.email.EmailSender;
import com.r2r.subsorder.model.SubscriptionOrder;
import com.r2r.subsorder.service.SubsOrderService;

public class SubsPlanEmail extends QuartzJobBean{

	private SubsOrderService subsOrderService;
	
	@Autowired(required=true)
	@Qualifier(value="subsOrderService")
	public void setSubsOrderService(SubsOrderService sos){
		this.subsOrderService = sos;
	}
	
	@Override
	public void executeInternal(JobExecutionContext jExeCtx) throws JobExecutionException{
		List<SubscriptionOrder> subsOrderList = this.subsOrderService.getSubsOrder(true);
		
		Long month = 2592000000L;
		Long week = 604800000L;
		Long day = 86400000L;
		
		EmailSender emailSender = new EmailSender();
		
		String subject = "Subscription Plan Ending";
		
		String message = "Your'e subscription plan is going to end in ";
		
		for(SubscriptionOrder subsOrder : subsOrderList){
			
			BigInteger timeDiff = subsOrder.getSubsOrderDate().subtract(BigInteger.valueOf(System.currentTimeMillis()));
		/*	
			if(timeDiff < month && timeDiff > 2505600000L )
				emailSender.sendEmail(subsOrder.getCustEmail(), subject, message + "1 month");
			else if(timeDiff < week && timeDiff > 518400000L)
				emailSender.sendEmail(subsOrder.getCustEmail(), subject, message + "1 week");
			else if(timeDiff < day)
				emailSender.sendEmail(subsOrder.getCustEmail(), subject, message + "1 day");
				*/
		}
		
	}
	
}
