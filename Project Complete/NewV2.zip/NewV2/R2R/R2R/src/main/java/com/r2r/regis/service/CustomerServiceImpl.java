package com.r2r.regis.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.r2r.book.model.Book;
import com.r2r.regis.dao.CustomerDAO;
import com.r2r.regis.model.Customer;

public class CustomerServiceImpl implements CustomerService {
	
	private CustomerDAO customerDAO;
	
	public void setCustomerDAO(CustomerDAO customerDAO){
		this.customerDAO = customerDAO;
	}
	
	@Override
	@Transactional
	public void addCustomer(Customer c){
		this.customerDAO.addCustomer(c);
	}
	
	@Override
	@Transactional
	public void updateCustomer(Customer c){
		this.customerDAO.updateCustomer(c);
	}
	
	@Override
	@Transactional
	public List<Customer> listCustomers(){
		return this.customerDAO.listCustomers();
	}
	
	@Override
	@Transactional
	public Customer  getCustomerByPasskey(String passkey){
		return this.customerDAO.getCustomerByPasskey(passkey);
	}
	
	@Override
	@Transactional
	public Customer  getCustomerById(String emailId){
		return this.customerDAO.getCustomerById(emailId);
	}
	
	@Override
	@Transactional
	public void removeCustomer(String emailId){
		this.customerDAO.removeCustomer(emailId);
	}
}
