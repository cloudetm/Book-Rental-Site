package com.r2r.cart.dao;

import java.util.List;

import com.r2r.cart.model.Cart;

public interface CartDAO {

	public void addItemToCart(Cart c);
	public List <Cart> getAll(String cust_email);
	public void removeItem(Cart c);
	public void emptyCart(String cust_email);
	
}
