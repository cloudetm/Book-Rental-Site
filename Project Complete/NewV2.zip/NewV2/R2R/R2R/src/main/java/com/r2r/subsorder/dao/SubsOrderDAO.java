package com.r2r.subsorder.dao;

import java.util.List;

import com.r2r.subsorder.model.SubscriptionOrder;

public interface SubsOrderDAO {
	
	public void generateSubsOrder(SubscriptionOrder subsOrder);
	public List <SubscriptionOrder> getSubsOrder(Boolean subs_order_status);
	public void updateSubsOrder(SubscriptionOrder subsOrder);
	public List<SubscriptionOrder> getAll();
}
