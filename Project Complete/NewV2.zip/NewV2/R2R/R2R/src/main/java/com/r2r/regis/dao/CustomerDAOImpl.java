package com.r2r.regis.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.r2r.book.model.Book;
import com.r2r.hibernate.util.HibernateAnnotationUtil;
import com.r2r.regis.model.Customer;

@Repository
public class CustomerDAOImpl implements CustomerDAO {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	@Override
	public void addCustomer(Customer c){
		Session session = this.sessionFactory.getCurrentSession();
		session.save(c);
		
	}
	
	@Override
	public void updateCustomer(Customer c){
		Session session = this.sessionFactory.getCurrentSession();
		session.update(c);
		session.flush();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> listCustomers(){
		Session session = this.sessionFactory.getCurrentSession();
		List<Customer> customerList = session.createQuery("from Customer").list();
		return customerList;
	}
	
	@Override 
	public Customer getCustomerByPasskey(String passkey){
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM Customer C WHERE C.custPasskey = :passkey";
		Query query = session.createQuery(hql);
		query.setParameter("passkey", passkey);
		List <Customer> cl = query.list();
		Customer c = new Customer();
		for(Customer ci : cl){
			c = ci;
		}
		return c;
	}
	
	@Override 
	public Customer getCustomerById(String custEmail){
		Session session = this.sessionFactory.getCurrentSession();
		Customer c = (Customer) session.get(Customer.class, new String(custEmail));
		return c;
	}
	
	@Override
	public void removeCustomer(String emailId){
		Session session = this.sessionFactory.getCurrentSession();
		Customer c = (Customer) session.load(Customer.class, new String(emailId));
	}
}
