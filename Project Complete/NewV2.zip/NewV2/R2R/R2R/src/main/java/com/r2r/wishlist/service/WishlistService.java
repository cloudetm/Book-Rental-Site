package com.r2r.wishlist.service;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.r2r.hibernate.util.HibernateAnnotationUtil;
import com.r2r.regis.model.Customer;
import com.r2r.wishlist.model.Wishlist;


public class WishlistService {

	
	
	public void addItem(Customer customer){
		SessionFactory sessionFactory;
		sessionFactory = HibernateAnnotationUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.update(customer);
		tx.commit();
		sessionFactory.close();
	}
	
	public void deleteItem(Customer customer){
		SessionFactory sessionFactory;
		sessionFactory = HibernateAnnotationUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.delete(customer);
		tx.commit();
		sessionFactory.close();
		
	}
	
	public Customer getAll(String custEmail){
		SessionFactory sessionFactory;
		sessionFactory = HibernateAnnotationUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Customer customer = (Customer) session.load(Customer.class, custEmail);
		tx.commit();
		sessionFactory.close();
		return customer;
	}
	
	public void removeAll(String cust_email){
		SessionFactory sessionFactory;
		sessionFactory = HibernateAnnotationUtil.getSessionFactory();
		
	}
}
