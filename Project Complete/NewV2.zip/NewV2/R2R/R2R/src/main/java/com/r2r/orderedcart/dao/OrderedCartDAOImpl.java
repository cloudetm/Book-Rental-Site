package com.r2r.orderedcart.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.r2r.order.model.Order;
import com.r2r.orderedcart.model.OrderedCart;

@Repository
public class OrderedCartDAOImpl implements OrderedCartDAO {

	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	@Override
	public void createOrderedCart(List <OrderedCart> oCartList) {
		Session session = this.sessionFactory.getCurrentSession();
		for(OrderedCart oCart : oCartList){
			
			session.save(oCart);
			session.flush();
		}

	}

	@Override
	public List<OrderedCart> getOrderedCartByOrderId(int orderId) {
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM OrderedCart OC WHERE OC.orderId = :orderId";
		Query query = session.createQuery(hql);
		query.setParameter("orderId", orderId);
		List <OrderedCart> oCartList = query.list();
		return oCartList;
	}

}
