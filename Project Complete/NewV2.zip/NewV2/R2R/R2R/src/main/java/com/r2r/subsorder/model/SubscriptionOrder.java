package com.r2r.subsorder.model;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.r2r.regis.model.Customer;
import com.r2r.subsplan.model.SubscriptionPlan;


/**
 * The persistent class for the SubscriptionOrder database table.
 * 
 */
@Entity
	@Table(name="SubscriptionOrder")
public class SubscriptionOrder{
	

	@Id
	@Column(name="subsOrderId")
	private int subsOrderId;
	@Column(name="subsOrderDate")
	private BigInteger subsOrderDate;
	@Column(name="subsOrderStatus")
	private Boolean subsOrderStatus;

	//bi-directional many-to-one association to SubscriptionPlan
	@ManyToOne
	@JoinColumn(name="subsId")
	private SubscriptionPlan subsPlan; 

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="custEmail")
	private Customer customerSubsOrder;

	public int getSubsOrderId() {
		return subsOrderId;
	}

	public void setSubsOrderId(int subsOrderId) {
		this.subsOrderId = subsOrderId;
	}

	public BigInteger getSubsOrderDate() {
		return subsOrderDate;
	}

	public void setSubsOrderDate(BigInteger subsOrderDate) {
		this.subsOrderDate = subsOrderDate;
	}

	public Boolean getSubsOrderStatus() {
		return subsOrderStatus;
	}

	public void setSubsOrderStatus(Boolean subsOrderStatus) {
		this.subsOrderStatus = subsOrderStatus;
	}

	public SubscriptionPlan getSubsPlan() {
		return subsPlan;
	}

	public void setSubsPlan(SubscriptionPlan subsPlan) {
		this.subsPlan = subsPlan;
	}

	public Customer getCustomerSubsOrder() {
		return customerSubsOrder;
	}

	public void setCustomer(Customer customerSubsOrder) {
		this.customerSubsOrder = customerSubsOrder;
	}

}