package com.r2r.subsplan.model;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.r2r.subsorder.model.SubscriptionOrder;


/**
 * The persistent class for the SubscriptionPlan database table.
 * 
 */
@Entity
	@Table(name="SubscriptionPlan")
public class SubscriptionPlan{
	

	@Id
	@Column(name="subsId")
	private int subsId;
	    @Column(name="subsDeliveries")
	private int subsDeliveries;
	    @Column(name="subsDeliveryCharges")
	private int subsDeliveryCharges;
	    @Column(name="subsDuration")
	private int subsDuration;
	    @Column(name="subsMaxMagzines")
	private int subsMaxMagzines;
	    @Column(name="subsMembershipFee")
	private int subsMembershipFee;
	    @Column(name="subsName")
	private String subsName;
	    @Column(name="subsPerDelivery")
	private int subsPerDelivery;
	    @Column(name="subsRefundableSecurity")
	private int subsRefundableSecurity;
	    @Column(name="subsSubscriptionFee")
	private BigDecimal subsSubscriptionFee;
	    @Column(name="subsSuitableFor")
	private String subsSuitableFor;
	    @Column(name="subsTotalBooks")
	private int subsTotalBooks;

	//bi-directional many-to-one association to SubscriptionOrder
	@OneToMany(mappedBy="subsPlan")
	@JsonIgnore
	private List<SubscriptionOrder> subsOrders;


	public int getSubsId() {
		return subsId;
	}

	public void setSubsId(int subsId) {
		this.subsId = subsId;
	}

	public int getSubsDeliveries() {
		return subsDeliveries;
	}

	public void setSubsDeliveries(int subsDeliveries) {
		this.subsDeliveries = subsDeliveries;
	}

	public int getSubsDeliveryCharges() {
		return subsDeliveryCharges;
	}

	public void setSubsDeliveryCharges(int subsDeliveryCharges) {
		this.subsDeliveryCharges = subsDeliveryCharges;
	}

	public int getSubsDuration() {
		return subsDuration;
	}

	public void setSubsDuration(int subsDuration) {
		this.subsDuration = subsDuration;
	}

	public int getSubsMaxMagzines() {
		return subsMaxMagzines;
	}

	public void setSubsMaxMagzines(int subsMaxMagzines) {
		this.subsMaxMagzines = subsMaxMagzines;
	}

	public int getSubsMembershipFee() {
		return subsMembershipFee;
	}

	public void setSubsMembershipFee(int subsMembershipFee) {
		this.subsMembershipFee = subsMembershipFee;
	}

	public String getSubsName() {
		return subsName;
	}

	public void setSubsName(String subsName) {
		this.subsName = subsName;
	}

	public int getSubsPerDelivery() {
		return subsPerDelivery;
	}

	public void setSubsPerDelivery(int subsPerDelivery) {
		this.subsPerDelivery = subsPerDelivery;
	}

	public int getSubsRefundableSecurity() {
		return subsRefundableSecurity;
	}

	public void setSubsRefundableSecurity(int subsRefundableSecurity) {
		this.subsRefundableSecurity = subsRefundableSecurity;
	}

	public BigDecimal getSubsSubscriptionFee() {
		return subsSubscriptionFee;
	}

	public void setSubsSubscriptionFee(BigDecimal subsSubscriptionFee) {
		this.subsSubscriptionFee = subsSubscriptionFee;
	}

	public String getSubsSuitableFor() {
		return subsSuitableFor;
	}

	public void setSubsSuitableFor(String subsSuitableFor) {
		this.subsSuitableFor = subsSuitableFor;
	}

	public int getSubsTotalBooks() {
		return subsTotalBooks;
	}

	public void setSubsTotalBooks(int subsTotalBooks) {
		this.subsTotalBooks = subsTotalBooks;
	}

	public List<SubscriptionOrder> getSubsOrders() {
		return subsOrders;
	}

	public void setSubscriptionOrders(List<SubscriptionOrder> subsOrders) {
		this.subsOrders = subsOrders;
	}

}