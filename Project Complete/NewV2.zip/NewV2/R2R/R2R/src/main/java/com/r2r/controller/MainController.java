package com.r2r.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;




import org.json.JSONException;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.apache.commons.codec.digest.DigestUtils;

import com.r2r.book.model.Book;
import com.r2r.book.parser.CSVParser;
import com.r2r.book.service.BookService;
import com.r2r.email.EmailSender;
import com.r2r.regis.model.Customer;
import com.r2r.regis.model.CustomerUpdate;
import com.r2r.model.ChoosePlan;
import com.r2r.model.RequestMessage;
import com.r2r.regis.service.CustomerService;
import com.r2r.report.PDFReport;
import com.r2r.model.ResponseMessage;
import com.r2r.order.model.Order;
import com.r2r.order.service.OrderService;
import com.r2r.search.searching.BookESearch;
import com.r2r.subsorder.model.SubscriptionOrder;
import com.r2r.subsorder.service.SubsOrderService;
import com.r2r.subsplan.model.SubscriptionPlan;
import com.r2r.subsplan.parser.XMLParser;
import com.r2r.subsplan.service.SubsPlanService;
import com.r2r.wishlist.model.Wishlist;
import com.r2r.wishlist.service.WishlistService;

@Controller
public class MainController {

	private CustomerService customerService;
	private SubsPlanService subsPlanService;
	private BookService bookService;
	private SubsOrderService subsOrderService;
	
	@Autowired(required=true)
	@Qualifier(value="customerService")
	public void setCustomerService(CustomerService cs){
		this.customerService = cs;
	}
	
	@Autowired(required=true)
	@Qualifier(value="subsPlanService")
	public void setSubsPlanService(SubsPlanService ss){
		this.subsPlanService = ss;
	}
	
	@Autowired(required=true)
	@Qualifier(value="bookService")
	public void setBookService(BookService bs){
		this.bookService = bs;
	}
	
	@Autowired(required=true)
	@Qualifier(value="subsOrderService")
	public void setSubsOrderService(SubsOrderService sos){
		this.subsOrderService = sos;
	}
	
	
	@RequestMapping(value = MainControllerURIConstant.HOME, method = RequestMethod.GET)
	public String home() {
		   return "redirect:/pages/index.html";
	   }
	
	@RequestMapping(value = MainControllerURIConstant.UPLOAD_PLANS_HTML, method = RequestMethod.GET)
	public String uploadPlansPage(){
		return "redirect:/pages/plans/index.html";
	}
	
	@RequestMapping(value = MainControllerURIConstant.UPLOAD_BOOKS_HTML, method = RequestMethod.GET)
	public String uploadBooksPage(){
		return "redirect:/pages/books/index.html";
	}
	
	@RequestMapping(value = MainControllerURIConstant.GET_ALL_CUSTOMERS, method = RequestMethod.GET)
    public @ResponseBody List<Customer> listCustomers() {
       
        List<Customer> customerList = this.customerService.listCustomers();
        for(Customer c : customerList){
        	System.out.print(c);
        	System.out.print(c.getCustEmail());
        }
        return customerList;
    }
     
    @RequestMapping(value = MainControllerURIConstant.REGISTER_CUSTOMER, method = RequestMethod.POST)
    public @ResponseBody ResponseMessage registerCustomer(@RequestBody Customer c){
         
    	long time = System.currentTimeMillis();
        c.setCustRegDate(BigInteger.valueOf(time));  
        
    	String hashCode = DigestUtils.sha256Hex(c.getCustEmail()+c.getCustFirstName()+c.getCustMiddleName()+c.getCustLastName()+
    			c.getCustAddress()+c.getCustCity()+c.getCustState()+c.getCustDOB()+c.getCustMobileNo()+c.getCustPincode()+c.getCustPassword()+c.getCustRegDate());
    	
    	c.setCustPasskey(hashCode);
    	        
        c.setCustIsVerified(false);
        
        this.customerService.addCustomer(c);
    	

        EmailSender emailSender = new EmailSender();
        emailSender.sendEmail(c.getCustEmail(), "Verify You EmailId.", "Verify You EmailId by going to this url: http://localhost:8080/r2r/verify?passkey="+c.getCustPasskey());
    	ResponseMessage respMessage = new ResponseMessage();
    	respMessage.setEmailId(c.getCustEmail());
    	respMessage.setMessage("Verify your mail id ");
    	
    	return respMessage;
         
    }
    
    @RequestMapping(value = MainControllerURIConstant.VERIFY_EMAIL, method = RequestMethod.GET)
    public @ResponseBody ResponseMessage verifyEmail(@RequestParam("passkey") String passkey)
    {
    	
    	Customer c = this.customerService.getCustomerByPasskey(passkey);

    	//System.out.println("w2");

    	c.setCustIsVerified(true);
    	
    	c.setCustPasskey(null);
    	//System.out.println("w3");
    	
    	this.customerService.updateCustomer(c);
    	
    	ResponseMessage respMessage = new ResponseMessage();
    	
    	respMessage.setEmailId(c.getCustEmail());
    	respMessage.setMessage("You are registered.");
    	
    	return respMessage;
    	
    }
  
    @RequestMapping(value = MainControllerURIConstant.UPDATE_ADDRESS, method = RequestMethod.POST)
    public @ResponseBody ResponseMessage editCustomer(@RequestBody CustomerUpdate cu){
    	System.out.println("w1");
    	Customer c = this.customerService.getCustomerById(cu.getCustEmail());
    	System.out.println("w2");
    	c.setCustAddress(cu.getCustAddress());
    	c.setCustCity(cu.getCustCity());
    	c.setCustState(cu.getCustState());
    	c.setCustPincode(BigInteger.valueOf(cu.getCustPincode()));
    	c.setCustMobileNo(BigInteger.valueOf(cu.getCustMobileNo()));
    	System.out.println("w3");
    	this.customerService.updateCustomer(c);
    	System.out.println("w4");
    	ResponseMessage respMessage = new ResponseMessage();
    	respMessage.setEmailId(c.getCustEmail());
    	respMessage.setMessage("Updated your email id");
    	
    	return respMessage;
    	
    }
    
	
    @RequestMapping(value = MainControllerURIConstant.LOGIN , method=RequestMethod.POST)
    public @ResponseBody ResponseMessage loggedIn(@RequestBody RequestMessage req){
		
		
		Customer c = this.customerService.getCustomerById(req.getCustEmail());
		
		ResponseMessage respMessage = new ResponseMessage();
		respMessage.setEmailId(c.getCustEmail());
		
		if(c.getCustPassword().equals(req.getCustPassword()) && c.getCustIsVerified().equals(true)){
			respMessage.setMessage("Welcome");
		}
		else if(c.getCustIsVerified().equals(false)){
			respMessage.setMessage("You are not verified");
		}
		else{
			respMessage.setMessage("Wrong Credentials");
			respMessage.setEmailId("Who are you");
		}
		
		
		return respMessage;
	}
 
    @RequestMapping(value = MainControllerURIConstant.FORGOT_PASSWORD, method=RequestMethod.POST)
    public @ResponseBody ResponseMessage forgotPassword(@RequestBody RequestMessage req){
 	
    	Customer c = this.customerService.getCustomerById(req.getCustEmail());
 	
    	Random rGen = new Random();
    	Integer randInt = rGen.nextInt(1000000);
 	
    	String hashCode = DigestUtils.md5Hex(Integer.toString(randInt));
 	
    	c.setCustPasskey(hashCode);
    	this.customerService.updateCustomer(c);
    	
    	String toEmail = c.getCustEmail();
    	String subject = "Go to your email to change password!";
    	String message = "Change your password using this url http://localhost:8080/r2r/forget/change?passkey="+hashCode;
     
    	EmailSender emailSend = new EmailSender();
    	emailSend.sendEmail(toEmail, subject, message);
    	
    	ResponseMessage respMessage = new ResponseMessage();
    	respMessage.setEmailId(c.getCustEmail());
    	respMessage.setMessage("URL has been sent to your mail.");
 	
    	return respMessage;
 	}
    
    @RequestMapping(value = MainControllerURIConstant.CHANGE_PASSWORD, method={RequestMethod.GET, RequestMethod.POST})
    public @ResponseBody ResponseMessage changePassword(@RequestParam("passkey") String passkey, @RequestBody RequestMessage req){
    	
    	Customer c = this.customerService.getCustomerById(req.getCustEmail());
    	System.out.println(passkey);
    	if(c.getCustPasskey().equals(passkey)){
    		c.setCustPassword(req.getCustPassword());
    	}
    	c.setCustPasskey(null);
    	this.customerService.updateCustomer(c);
    	
    	ResponseMessage respMessage = new ResponseMessage();
    	respMessage.setEmailId(c.getCustEmail());
    	respMessage.setMessage("Password Changed");
    	
    	return respMessage;
    }
    
	
	@RequestMapping(value = MainControllerURIConstant.ADD_PLANS, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage addPlans(@RequestParam("file") MultipartFile file) {

		
		ResponseMessage respMessage = new ResponseMessage();
    	respMessage.setEmailId("admin@r2r.com");
    	
		String name = "SubscriptionPlanAdd.xml";
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				
				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();
				
				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath() + File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				
				//logger.info("Server File Location="	+ serverFile.getAbsolutePath());
				System.out.println(serverFile.getAbsolutePath());
				
				XMLParser domParser = new XMLParser();
				List<SubscriptionPlan> subsPlanList = domParser.parseit(serverFile.getAbsolutePath());
				
				this.subsPlanService.addPlans(subsPlanList);			
				
		    	respMessage.setMessage("Successfuly uploaded");
		    	
		    	return respMessage;
		    	
			} catch (Exception e) {
				respMessage.setMessage("You failed to upload " + name + " => " + e.getMessage());
		    	
		    	return respMessage;
			}
		} else {
			
			respMessage.setMessage("You failed to upload " + name + " because the file was empty.");
	    	
	    	return respMessage;
		}
	}
	
	@RequestMapping(value = MainControllerURIConstant.UPDATE_PLANS, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage updatePlans(@RequestParam("file") MultipartFile file) {

		ResponseMessage respMessage = new ResponseMessage();
    	respMessage.setEmailId("admin@r2r.com");
    	
		String name = "SubscriptionPlanUpdate.xml";
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				System.out.println("1");
				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();
				System.out.println("2");
				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath() + File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				System.out.println("3");
				//logger.info("Server File Location="	+ serverFile.getAbsolutePath());
				System.out.println(serverFile.getAbsolutePath());
				
				XMLParser domParser = new XMLParser();
				List<SubscriptionPlan> subsPlanList = domParser.parseit(serverFile.getAbsolutePath());
				
				this.subsPlanService.updatePlans(subsPlanList);			
				
				respMessage.setMessage("Successfuly uploaded");
		    	
		    	return respMessage;
		    	
			} catch (Exception e) {
				respMessage.setMessage("You failed to upload " + name + " => " + e.getMessage());
		    	
		    	return respMessage;
			}
		} else {
			
			respMessage.setMessage("You failed to upload " + name + " because the file was empty.");
	    	
	    	return respMessage;
		}
	}
	
	@RequestMapping(value = MainControllerURIConstant.DELETE_PLANS, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage uploadFileHandler(@RequestParam("file") MultipartFile file) {

		ResponseMessage respMessage = new ResponseMessage();
    	respMessage.setEmailId("admin@r2r.com");
    	
		String name = "SubscriptionPlanDELETE.xml";
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				System.out.println("1");
				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();
				System.out.println("2");
				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath() + File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				System.out.println("3");
				//logger.info("Server File Location="	+ serverFile.getAbsolutePath());
				System.out.println(serverFile.getAbsolutePath());
				
				XMLParser domParser = new XMLParser();
				List<SubscriptionPlan> subsPlanList = domParser.parseit(serverFile.getAbsolutePath());
				
				this.subsPlanService.deletePlans(subsPlanList);			
				
				respMessage.setMessage("Successfuly uploaded");
		    	
		    	return respMessage;
		    	
			} catch (Exception e) {
				respMessage.setMessage("You failed to upload " + name + " => " + e.getMessage());
		    	
		    	return respMessage;
			}
		} else {
			
			respMessage.setMessage("You failed to upload " + name + " because the file was empty.");
	    	
	    	return respMessage;
		}
	}
	
	@RequestMapping(value = MainControllerURIConstant.GET_ALL_PLANS, method = RequestMethod.GET)
	public @ResponseBody List<SubscriptionPlan> getAllPlans(){
		
		List<SubscriptionPlan> subsPlanList = this.subsPlanService.getAll();
		
		return subsPlanList;
		
	}

	
	@RequestMapping(value = MainControllerURIConstant.GET_ALL_BOOKS, method = RequestMethod.GET)
	public @ResponseBody List<Book> getAllBooks() {
		List<Book> bookList = this.bookService.getAll();
		return bookList;
	}
	
	@RequestMapping(value = MainControllerURIConstant.SEARCH_BOOKS, method = RequestMethod.GET)
	public @ResponseBody List<Book> searchBooks(HttpServletRequest request, @RequestParam("query") String query, @RequestParam("filter") String filter ) throws UnsupportedEncodingException, IOException, JSONException{
		
		BookESearch bookESearch = new BookESearch();
		
		List<Book> bookList = bookESearch.getRelated(query,filter);
		
		return bookList;
	}
	
	@RequestMapping(value = MainControllerURIConstant.GET_BOOK_BY_ID, method = RequestMethod.GET)
	public @ResponseBody Book getBook(@RequestParam("bookId") Integer bookId){
		Book book = this.bookService.getById(bookId);
		return book;
	}
	
	@RequestMapping(value = MainControllerURIConstant.ADD_BOOK, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage addBook(@RequestBody Book book){
		this.bookService.addBook(book);
		
		ResponseMessage respMessage = new ResponseMessage();
		respMessage.setEmailId("admin@r2r.com");
		respMessage.setMessage(Integer.toString(book.getBookId()) + " added.");
		
		return respMessage;
	}
	
	@RequestMapping(value = MainControllerURIConstant.UPDATE_BOOK_BY_ID, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage updateBook(@RequestBody Book book){
		this.bookService.updateBook(book);
		
		ResponseMessage respMessage = new ResponseMessage();
		respMessage.setEmailId("admin@r2r.com");
		respMessage.setMessage(Integer.toString(book.getBookId()) + " updated.");
		
		return respMessage;
		
	}
	
	@RequestMapping(value = MainControllerURIConstant.DELETE_BOOK_BY_ID, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage deleteBook(@RequestBody Book book){
		this.bookService.deleteBook(book);
		
		ResponseMessage respMessage = new ResponseMessage();
		respMessage.setEmailId("admin@r2r.com");
		respMessage.setMessage(Integer.toString(book.getBookId()) + " deleted.");
		
		return respMessage;
		
	}
	
	@RequestMapping(value = MainControllerURIConstant.ADD_BOOKS_FROM_CSV, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage addBooks(@RequestParam("file") MultipartFile file) {

		ResponseMessage respMessage = new ResponseMessage();
    	respMessage.setEmailId("admin@r2r.com");
    	
		String name = "bookadd.csv";
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				
				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();
				
				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath() + File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				 
				//logger.info("Server File Location="	+ serverFile.getAbsolutePath());
				System.out.println(serverFile.getAbsolutePath());
				
				CSVParser csvParser = new CSVParser();
				List<Book> bookList = csvParser.parseToBooks(serverFile.getAbsolutePath());
				
				this.bookService.addBooks(bookList);			
				
				respMessage.setMessage("Successfuly uploaded");
		    	
		    	return respMessage;
		    	
			} catch (Exception e) {
				respMessage.setMessage("You failed to upload " + name + " => " + e.getMessage());
		    	
		    	return respMessage;
			}
		} else {
			
			respMessage.setMessage("You failed to upload " + name + " because the file was empty.");
	    	
	    	return respMessage;
		}
	}
	
	@RequestMapping(value = MainControllerURIConstant.UPDATE_BOOKS_FROM_CSV, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage updateBooks(@RequestParam("file") MultipartFile file) {

		ResponseMessage respMessage = new ResponseMessage();
    	respMessage.setEmailId("admin@r2r.com");
    	
		String name = "bookupdate.csv";
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				
				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();
				
				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath() + File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				 
				//logger.info("Server File Location="	+ serverFile.getAbsolutePath());
				System.out.println(serverFile.getAbsolutePath());
				
				CSVParser csvParser = new CSVParser();
				List<Book> bookList = csvParser.parseToBooks(serverFile.getAbsolutePath());
				
				this.bookService.updateBooks(bookList);			
				
				respMessage.setMessage("Successfuly uploaded");
		    	
		    	return respMessage;
		    	
			} catch (Exception e) {
				respMessage.setMessage("You failed to upload " + name + " => " + e.getMessage());
		    	
		    	return respMessage;
			}
		} else {
			
			respMessage.setMessage("You failed to upload " + name + " because the file was empty.");
	    	
	    	return respMessage;
		}
	}
	
	@RequestMapping(value = MainControllerURIConstant.DELETE_BOOKS_FROM_CSV, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage deleteBooks(@RequestParam("file") MultipartFile file) {

		ResponseMessage respMessage = new ResponseMessage();
    	respMessage.setEmailId("admin@r2r.com");
    	
		String name = "bookdelete.csv";
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				
				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();
				
				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath() + File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				 
				//logger.info("Server File Location="	+ serverFile.getAbsolutePath());
				System.out.println(serverFile.getAbsolutePath());
				
				CSVParser csvParser = new CSVParser();
				List<Book> bookList = csvParser.parseToBooks(serverFile.getAbsolutePath());
				
				this.bookService.deleteBooks(bookList);			
				
				respMessage.setMessage("Successfuly uploaded");
		    	
		    	return respMessage;
		    	
			} catch (Exception e) {
				respMessage.setMessage("You failed to upload " + name + " => " + e.getMessage());
		    	
		    	return respMessage;
			}
		} else {
			
			respMessage.setMessage("You failed to upload " + name + " because the file was empty.");
	    	
	    	return respMessage;
		}
	}
	
	

	@RequestMapping(value = MainControllerURIConstant.SUBSCRIBE_PLAN, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage subscribePlan(@RequestBody ChoosePlan choosePlan){
		
		Customer  customer = this.customerService.getCustomerById(choosePlan.getCustEmail());
		SubscriptionPlan subsPlan = this.subsPlanService.getPlanById(choosePlan.getSubsId());
	
		List<SubscriptionOrder> subsOrderList = this.subsOrderService.getSubsOrder(true);
		
		ResponseMessage respMessage = new ResponseMessage();
		
		for(SubscriptionOrder subsOrderOld : subsOrderList){
			if(subsOrderOld.getCustomerSubsOrder().getCustEmail().equals(choosePlan.getCustEmail()) && subsOrderOld.getSubsOrderStatus().equals(true)){
				subsOrderOld.setSubsOrderStatus(false);
				this.subsOrderService.updateSubsOrder(subsOrderOld);
				
				Long subsOrderDate = System.currentTimeMillis();
				
				SubscriptionOrder subsOrderNew = new SubscriptionOrder();
				subsOrderNew.setCustomer(customer);
				subsOrderNew.setSubsOrderDate(BigInteger.valueOf(subsOrderDate));
				subsOrderNew.setSubsPlan(subsPlan);
				subsOrderNew.setSubsOrderStatus(true);
				
				this.subsOrderService.generateSubsOrder(subsOrderNew);
				
				respMessage.setEmailId(customer.getCustEmail());
				respMessage.setMessage("You moved to plan " + subsOrderNew.getSubsPlan().getSubsId());
				
				return respMessage;
			}
		}
		
		
			SubscriptionOrder subsOrderNew = new SubscriptionOrder();
			System.out.println("6");
			
			subsOrderNew.setCustomer(customer);
			subsOrderNew.setSubsPlan(subsPlan);
			
			Long subsOrderDate = System.currentTimeMillis();
			subsOrderNew.setSubsOrderDate(BigInteger.valueOf(subsOrderDate));
			subsOrderNew.setSubsOrderStatus(true);
			
			this.subsOrderService.generateSubsOrder(subsOrderNew);
			
			respMessage.setEmailId(choosePlan.getCustEmail());
			respMessage.setMessage("You choosed " + choosePlan.getSubsId() + " plan and order id is " + subsOrderNew.getSubsOrderId());			
		
			return respMessage;
	}

	@RequestMapping(value = MainControllerURIConstant.ACTIVE_SUBSCRIPTIONS, method = RequestMethod.GET)
	public @ResponseBody List <SubscriptionOrder> getActiveSubscriptions(){
		
		List <SubscriptionOrder> subsOrderList = this.subsOrderService.getSubsOrder(true);
		return subsOrderList;
	}
	
	@RequestMapping(value = MainControllerURIConstant.NONACTIVE_SUBSCRIPTIONS, method = RequestMethod.GET)
	public @ResponseBody List<SubscriptionOrder> getNonActiveSubscriptions(){
		
		List<SubscriptionOrder> subsOrderList = this.subsOrderService.getSubsOrder(false);
		return subsOrderList;
	}
	
	@RequestMapping(value = MainControllerURIConstant.MY_SUBSCRIPTIONS, method = RequestMethod.GET)
	public @ResponseBody List <SubscriptionOrder> getMySubscriptions(@RequestParam(value = "custEmail", required = false) String custEmail){
		
		System.out.println(custEmail);
		List <SubscriptionOrder> subsOrderList = new ArrayList<SubscriptionOrder>();
		
		List<SubscriptionOrder> subsOrderAll = this.subsOrderService.getAll();

		for(SubscriptionOrder sO : subsOrderAll){
			if(sO.getCustomerSubsOrder().getCustEmail().equals(custEmail)){
				subsOrderList.add(sO);
			}
		}
			
		return subsOrderList;
	}

	
	@RequestMapping(value = MainControllerURIConstant.ADD_TO_WISHLIST, method = RequestMethod.POST)
	public @ResponseBody Wishlist addItemToWishlist(@RequestBody Wishlist w){
		
		WishlistService wS = new WishlistService();
		
		Customer customer = wS.getAll(w.getCustEmail());
		
		Book book = this.bookService.getById(w.getBookId());
		
		customer.addWishlistBook(book);
		
		wS.addItem(customer);
		
		return w;
		
	}
/*
	@RequestMapping(value = MainControllerURIConstant.REMOVE_FROM_WISHLIST, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage removeItemFromWishlist(@RequestBody Wishlist w){
		
		
		Customer customer = this.wishlistService.getAll(w.getCustEmail());
		Book book = this.bookService.getById(w.getBookId());

		System.out.print(1);
		customer.removeWishlistBook(book);
		this.wishlistService.deleteItem(customer);
		
		ResponseMessage respMessage = new ResponseMessage();
		
		respMessage.setEmailId(w.getCustEmail());
		respMessage.setMessage("deleted");
		
		return respMessage;
	}
/*	
	@RequestMapping(value = MainControllerURIConstant.REMOVE_ALL_WISHLIST, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage removeAllFromWishlist(@RequestParam("custEmail") String custEmail){
		
		this.wishlistService.removeAll(custEmail);
		
		ResponseMessage respMessage = new ResponseMessage();
		
		respMessage.setEmailId(custEmail);
		respMessage.setMessage("removed");
		
		return respMessage;
	}

	@RequestMapping(value = MainControllerURIConstant.GET_ALL_FROM_WISHLIST, method = RequestMethod.GET)
	public @ResponseBody List<Book> getAllFromWislist(@RequestParam("custEmail") String custEmail){
		
		Customer customer = this.wishlistService.getAll(custEmail);
		return customer.getWishlistBooks();
	}
	
	/*
	
	@RequestMapping(value = MainControllerURIConstant.ADD_ITEM_TO_CART, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage addItemToCart(@RequestBody Cart cart){
	
		Customer customer = this.customerService.getCustomerById(cart.getCustEmail());
		
		SubscriptionPlan subsPlan = this.subsPlanService.getPlanById(customer.getSubsId());
		
		List <Cart> cartList = this.cartService.getAll(cart.getCustEmail());
		
		int no_of_items = cartList.size();
		
		ResponseMessage respMessage = new ResponseMessage();
		
		if(no_of_items < subsPlan.getSubsPerDelivery()){
			this.cartService.addItemToCart(cart);
					
			respMessage.setEmailId(cart.getCustEmail());
			respMessage.setMessage(Integer.toString(cart.getBookId()) + " added");
		}
		else{
			
			respMessage.setEmailId(cart.getCustEmail());
			respMessage.setMessage("No more according to current subsplan");
		}
		return respMessage;
		
		
	}
	
	@RequestMapping(value = MainControllerURIConstant.GET_ALL_FROM_CART, method = RequestMethod.POST)
	public @ResponseBody List <Cart> getAllFromCart(@RequestParam("custEmail") String custEmail){
		
		List <Cart> cartList = this.cartService.getAll(custEmail);
		
		return cartList;
	}
	
	@RequestMapping(value = MainControllerURIConstant.REMOVE_ITEM, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage removeItemFromCart(@RequestBody Cart c){
		
		this.cartService.removeItem(c);
		
		ResponseMessage respMessage = new ResponseMessage();
		
		respMessage.setEmailId(c.getCustEmail());
		respMessage.setMessage(Integer.toString(c.getBookId()) + " deleted");
		
		return respMessage;
	}
	
	@RequestMapping(value = MainControllerURIConstant.EMPTY_CART, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage emaptyCart(@RequestParam("custEmail") String custEmail){
		
		this.cartService.emptyCart(custEmail);
		
		ResponseMessage respMessage = new ResponseMessage();
		
		respMessage.setEmailId(custEmail);
		respMessage.setMessage("cart flushed");
		
		return respMessage;
	}
	
	
	
	@RequestMapping(value = MainControllerURIConstant.CHECKOUT, method = RequestMethod.POST)
	public @ResponseBody Order checkout(@RequestParam("cartList") List <Cart> cartList, @RequestParam("custEmail") String custEmail){
		
		List <OrderedCart> orderedCartList = new ArrayList <OrderedCart>();
		
		Order order = new Order();
		
		order.setCustEmail(custEmail);
		
		Long order_date = System.currentTimeMillis();
		order.setOrderDate(order_date);
		order.setStatus("dp");
		
		for(Cart cart : cartList){
			OrderedCart orderedCart = new OrderedCart();
			Book book = this.getBook(cart.getBookId());
			book.setStatus(false);
			this.bookService.updateBook(book);
			
			orderedCart.setOrderId(order.getOrderId());
			orderedCart.setBookId(cart.getBookId());
			
			orderedCartList.add(orderedCart);
		}
		
		this.orderedCartService.createOrderedCart(orderedCartList);
		this.orderService.createOrder(order);
		this.cartService.emptyCart(custEmail);
		
		EmailSender emailSender = new EmailSender();
		emailSender.sendEmail(order.getCustEmail(), "Order Generated", Integer.toString(order.getOrderId()) + " is under process");
		return order;
	}
	
	@RequestMapping(value = MainControllerURIConstant.MY_ORDERS, method = RequestMethod.POST)
	public @ResponseBody List <Order> getAllOrderById(@RequestParam("custEmail") String custEmail){
		List <Order> orderList = this.orderService.getAllById(custEmail);
		return orderList;
	}
	
	@RequestMapping(value = MainControllerURIConstant.CANCEL_MY_ORDER, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage getCancelMyOrder(@RequestParam("custEmail") String custEmail){
		
		Order order = this.orderService.getOrderByCustIdAndStatus(custEmail, "dp");
		
		order.setStatus("dcl");
		
		List <OrderedCart> orderedCartList = this.orderedCartService.getOrderedCartByOrderId(order.getOrderId());
		
		for(OrderedCart orderedCart : orderedCartList){
			Book book = this.bookService.getById(orderedCart.getBookId());
			book.setStatus(true);
			this.bookService.updateBook(book);
		}
		
		EmailSender emailSender = new EmailSender();
		emailSender.sendEmail(order.getCustEmail(), "Order Cancelled", Integer.toString(order.getOrderId()) + " cancelled.");
		
		ResponseMessage respMessage = new ResponseMessage();
		
		respMessage.setEmailId(custEmail);
		respMessage.setMessage("Order Cancelled");
		
		return respMessage;
	
		
	}
	
	@RequestMapping(value = MainControllerURIConstant.PENDING_ORDERS, method = RequestMethod.GET)
	public @ResponseBody List <Order> pendingOrders(){
		List <Order> orderList = this.orderService.getOrderByStatus("dp");
		return orderList;
	}
	
	@RequestMapping(value = MainControllerURIConstant.COMPLETE_ORDERS, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage completeOrders(@RequestBody List <Order> orderList){
		
		EmailSender emailSender = new EmailSender();
		
		for(Order order : orderList){
			order.setStatus("dc");
			this.orderService.updateOrder(order);
			
			emailSender.sendEmail(order.getCustEmail(), "Delivery Enroute", Integer.toString(order.getOrderId()) + " is enroute.");
		}
		
		ResponseMessage respMessage = new ResponseMessage();
		respMessage.setEmailId("admin@r2r.com");
		respMessage.setMessage("All request completed");
		
		return respMessage;
	}
	
	@RequestMapping(value = MainControllerURIConstant.RETURN, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage returnOrder(@RequestBody Order order){
		
		order.setStatus("rp");
		
		EmailSender emailSender = new EmailSender();
		emailSender.sendEmail(order.getCustEmail(), "Return Requested", Integer.toString(order.getOrderId()) + " return is requested by you.");
		
		ResponseMessage respMessage = new ResponseMessage();
		respMessage.setEmailId("");
		respMessage.setMessage("Return Pending");
		
		return respMessage;
	}
	
	@RequestMapping(value = MainControllerURIConstant.CANCEL_RETURN, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage cancelMyReturn(@RequestBody Order order){
		order.setStatus("dc");
		
		EmailSender emailSender = new EmailSender();
		emailSender.sendEmail(order.getCustEmail(), "Return Request Cancelled", Integer.toString(order.getOrderId()) + " return request is cancelled by you.");
		
		ResponseMessage respMessage = new ResponseMessage();
		respMessage.setEmailId("");
		respMessage.setMessage("Return Cancelled");
		
		return respMessage;
	}
	
	@RequestMapping(value = MainControllerURIConstant.PENDING_RETURNS, method = RequestMethod.GET)
	public @ResponseBody List <Order> pendingReturns(){
		
		List <Order> orderList = this.orderService.getOrderByStatus("dp");
		
		return orderList;
	}
	
	@RequestMapping(value = MainControllerURIConstant.COMPLETE_RETURNS, method = RequestMethod.POST)
	public @ResponseBody ResponseMessage completeReturns(@RequestBody List <Order> orderList){
		
		for(Order order : orderList){
			
			order.setStatus("rc");
			this.orderService.updateOrder(order);
			
			List <OrderedCart> orderedCartList = this.orderedCartService.getOrderedCartByOrderId(order.getOrderId());
			for(OrderedCart orderedCart : orderedCartList){
				
				Book book = this.bookService.getById(orderedCart.getBookId());
				book.setStatus(true);
				this.bookService.updateBook(book);
			}
			
			EmailSender emailSender = new EmailSender();
			emailSender.sendEmail(order.getCustEmail(), "Return Request Completed", Integer.toString(order.getOrderId()) + " is with us now.");
			
		}
		
		ResponseMessage respMessage = new ResponseMessage();
		respMessage.setEmailId("admin@r2r.com");
		respMessage.setMessage("return request cleared");
		
		return respMessage;
	}
	
	@RequestMapping(value = MainControllerURIConstant.ALL_ORDERS, method = RequestMethod.GET)
	public @ResponseBody List <Order> allOrders(){
		
		List <Order> orderList = this.orderService.getAll();
		
		return orderList;
	}
	
	
	@RequestMapping(value = MainControllerURIConstant.ORDERED_ITEMS, method = RequestMethod.POST)
	public @ResponseBody List <OrderedCart> getOrderedCart(@RequestParam("orderId") int orderId){
		
		List <OrderedCart> orderedCartList = this.orderedCartService.getOrderedCartByOrderId(orderId);
		return orderedCartList;
	}

	@RequestMapping(value = MainControllerURIConstant.ALL_RENTED, method = RequestMethod.POST)
	public String allRented(@RequestParam("dateFrom") Date dateFrom, @RequestParam("dateTill") Date dateTill) throws Exception{
		Long dateFromT = dateFrom.getTime();
		Long dateTillT = dateTill.getTime();
		
		DateFormat df = new SimpleDateFormat("MMddyyyyHHmmss");
		
		Long currTime = System.currentTimeMillis();
		String reportId = df.format(currTime);
		
		String reportTitle = "All Rented";
		
		String reportPeriod = df.format(dateFrom) + " - " + df.format(dateTill);
		
		String filter = "All";
		
		
		List<Book> bookList = new ArrayList<Book>();
		
		List<Order> orderList = this.orderService.getAllBetweenDate(dateFromT, dateTillT);
		
		for(Order order : orderList){
			List<OrderedCart> orderedCartList = this.orderedCartService.getOrderedCartByOrderId(order.getOrderId());
			
			for(OrderedCart orderedCart : orderedCartList){
				Book book = this.bookService.getById(orderedCart.getBookId());
				bookList.add(book);
			}
		}
		
		PDFReport pdfReport = new PDFReport();
		String reportFileName = pdfReport.pdfReportGenerate(reportId, reportTitle, reportPeriod, filter, bookList);
		
		return "redirect:/reports/"+reportFileName;
	}
	
	@RequestMapping(value = MainControllerURIConstant.RENTED_BY_AUTHOR_NAME, method = RequestMethod.POST)
	public String rentedByAuthorName(@RequestParam("dateFrom") Date dateFrom, @RequestParam("dateTill") Date dateTill, @RequestParam("author") String author) throws Exception{
		Long dateFromT = dateFrom.getTime();
		Long dateTillT = dateTill.getTime();
		
		DateFormat df = new SimpleDateFormat("MMddyyyyHHmmss");
		
		Long currTime = System.currentTimeMillis();
		String reportId = df.format(currTime);
		
		String reportTitle = "Rented By Author Name";
		
		String reportPeriod = df.format(dateFrom) + " - " + df.format(dateTill);
		
		String filter = author;
		
		
		List<Book> bookList = new ArrayList<Book>();
		
		List<Order> orderList = this.orderService.getAllBetweenDate(dateFromT, dateTillT);
		
		for(Order order : orderList){
			List<OrderedCart> orderedCartList = this.orderedCartService.getOrderedCartByOrderId(order.getOrderId());
			
			for(OrderedCart orderedCart : orderedCartList){
				Book book = this.bookService.getById(orderedCart.getBookId());
				if(book.getAuthor().equals(author))
					bookList.add(book);
			}
		}
		
		PDFReport pdfReport = new PDFReport();
		String reportFileName = pdfReport.pdfReportGenerate(reportId, reportTitle, reportPeriod, filter, bookList);
		
		return "redirect:/reports/"+reportFileName;
	}
	
	@RequestMapping(value = MainControllerURIConstant.RENTED_BY_GENRE_NAME, method = RequestMethod.POST)
	public String rentedByGenreName(@RequestParam("dateFrom") Date dateFrom, @RequestParam("dateTill") Date dateTill, @RequestParam("genre") String genre) throws Exception{
		Long dateFromT = dateFrom.getTime();
		Long dateTillT = dateTill.getTime();
		
		DateFormat df = new SimpleDateFormat("MMddyyyyHHmmss");
		
		Long currTime = System.currentTimeMillis();
		String reportId = df.format(currTime);
		
		String reportTitle = "Rented By Author Name";
		
		String reportPeriod = df.format(dateFrom) + " - " + df.format(dateTill);
		
		String filter = genre;
		
		
		List<Book> bookList = new ArrayList<Book>();
		
		List<Order> orderList = this.orderService.getAllBetweenDate(dateFromT, dateTillT);
		
		for(Order order : orderList){
			List<OrderedCart> orderedCartList = this.orderedCartService.getOrderedCartByOrderId(order.getOrderId());
			
			for(OrderedCart orderedCart : orderedCartList){
				Book book = this.bookService.getById(orderedCart.getBookId());
				if(book.getGenre().equals(genre))
					bookList.add(book);
			}
		}
		
		PDFReport pdfReport = new PDFReport();
		String reportFileName = pdfReport.pdfReportGenerate(reportId, reportTitle, reportPeriod, filter, bookList);
		
		return "redirect:/reports/"+reportFileName;
	}
	*/
}