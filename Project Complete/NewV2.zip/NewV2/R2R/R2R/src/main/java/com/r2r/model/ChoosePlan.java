package com.r2r.model;

public class ChoosePlan {

	private String custEmail;
	private int subsId;
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public int getSubsId() {
		return subsId;
	}
	public void setSubsId(int subsId) {
		this.subsId = subsId;
	}
}
