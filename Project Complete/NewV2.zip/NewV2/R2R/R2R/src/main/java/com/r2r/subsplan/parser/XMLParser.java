package com.r2r.subsplan.parser;
 
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.ArrayList;
 
import com.r2r.subsplan.model.SubscriptionPlan;

public class XMLParser {
 
	public XMLParser(){}
	
	public List<SubscriptionPlan> parseit(String name) {
		System.out.println("in1");  
		List<SubscriptionPlan> subsPlanList = new ArrayList<SubscriptionPlan>();
		try {
 
			File fXmlFile = new File(name);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			//optional, but recommended
			//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();
			
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList nList = doc.getElementsByTagName("subscription");
			
			System.out.println("----------------------------");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
 
				Node nNode = nList.item(temp);
 
				System.out.println("\nCurrent Element :" + nNode.getNodeName());
 
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
 
					Element eElement = (Element) nNode;
			
					SubscriptionPlan subsPlan = new SubscriptionPlan();
			
					System.out.println("Subscription Id : " + eElement.getAttribute("id"));
					subsPlan.setSubsId(Integer.parseInt(eElement.getAttribute("id")));
					System.out.println("Subscription Name : " + eElement.getElementsByTagName("name").item(0).getTextContent());
					subsPlan.setSubsName( eElement.getElementsByTagName("name").item(0).getTextContent());
					System.out.println("Per Delivery : " + eElement.getElementsByTagName("per_derlivery").item(0).getTextContent());
					subsPlan.setSubsPerDelivery(Integer.parseInt(eElement.getElementsByTagName("per_derlivery").item(0).getTextContent()));
					System.out.println("Duration : " + eElement.getElementsByTagName("duration").item(0).getTextContent());
					subsPlan.setSubsDuration(Integer.parseInt(eElement.getElementsByTagName("duration").item(0).getTextContent()));
					System.out.println("Deliveries : " + eElement.getElementsByTagName("deliveries").item(0).getTextContent());
					subsPlan.setSubsDeliveries(Integer.parseInt(eElement.getElementsByTagName("deliveries").item(0).getTextContent()));
					System.out.println("Total Books : " + eElement.getElementsByTagName("total_books").item(0).getTextContent());
					subsPlan.setSubsTotalBooks(Integer.parseInt(eElement.getElementsByTagName("total_books").item(0).getTextContent()));
					System.out.println("Membership Fee : " + eElement.getElementsByTagName("membership_fee").item(0).getTextContent());
					subsPlan.setSubsMembershipFee(Integer.parseInt(eElement.getElementsByTagName("membership_fee").item(0).getTextContent()));
					System.out.println("Delivery Charges : " + eElement.getElementsByTagName("delivery_charges").item(0).getTextContent());
					subsPlan.setSubsDeliveryCharges(Integer.parseInt(eElement.getElementsByTagName("delivery_charges").item(0).getTextContent()));
					System.out.println("Refundable Security : " + eElement.getElementsByTagName("refundable_security").item(0).getTextContent());
					subsPlan.setSubsRefundableSecurity(Integer.parseInt(eElement.getElementsByTagName("refundable_security").item(0).getTextContent()));
					System.out.println("Subscription Fee : " + eElement.getElementsByTagName("subscription_fee").item(0).getTextContent());
					subsPlan.setSubsSubscriptionFee(new BigDecimal(eElement.getElementsByTagName("subscription_fee").item(0).getTextContent()));
					System.out.println("Suitable For : " + eElement.getElementsByTagName("suitable_for").item(0).getTextContent());
					subsPlan.setSubsSuitableFor(eElement.getElementsByTagName("suitable_for").item(0).getTextContent());
					System.out.println("Max Magazines : " + eElement.getElementsByTagName("max_magazines").item(0).getTextContent());
					subsPlan.setSubsMaxMagzines(Integer.parseInt(eElement.getElementsByTagName("max_magazines").item(0).getTextContent()));
					subsPlanList.add(subsPlan);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    
    return subsPlanList;
  }
  
 
}