package com.r2r.order.service;

import java.util.List;

import com.r2r.order.model.Order;

public interface OrderService {

	public void createOrder(Order o);
	public Order getOrderByCustIdAndStatus(String cust_email, String status);
	public void updateOrder(Order o);
	public List <Order> getAllById(String cust_email);
	public List<Order> getOrderByStatus(String status);
	public List<Order> getAll();
	public List<Order> getAllBetweenDate(Long dateFrom, Long dateTill);
	
}
