package com.r2r.book.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.r2r.book.dao.BookDAO;
import com.r2r.book.model.Book;

public class BookDAOImpl implements BookDAO {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Book> getAll() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Book> bookList = session.createQuery("from Book").list();
		return bookList;
	}
	
	@Override
	public Book getById(Integer bookId){
		Session session = this.sessionFactory.getCurrentSession();
		Book book = (Book) session.get(Book.class, new Integer(bookId));
		return book;
	}
	 
	@Override
	public void addBook(Book book){
		Session session = this.sessionFactory.getCurrentSession();
		session.save(book);
		session.flush();
	}
	
	@Override
	public void updateBook(Book book){
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(book);
		session.flush();
	}
	
	@Override
	public void deleteBook(Book book){
		Session session = this.sessionFactory.getCurrentSession();
		session.delete(book);
	}
	
	@Override
	public void addBooks(List <Book> bookList){
		Session session = this.sessionFactory.getCurrentSession();
		
		for(Book book : bookList){
			session.save(book);	
			session.flush();
		}
	}
	
	@Override
	public void updateBooks(List <Book> bookList){
		Session session = this.sessionFactory.getCurrentSession();
		
		for(Book book : bookList){
			session.saveOrUpdate(book);
			session.flush();
		}
	}
	
	@Override
	public void deleteBooks(List <Book> bookList){
		Session session = this.sessionFactory.getCurrentSession();
		
		for(Book book : bookList){
			session.delete(book);
		}
	}
}
