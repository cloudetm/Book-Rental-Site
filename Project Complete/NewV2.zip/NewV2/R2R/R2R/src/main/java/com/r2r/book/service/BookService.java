package com.r2r.book.service;

import java.util.List;

import com.r2r.book.model.Book;

public interface BookService {

	public List<Book> getAll();
	public Book getById(Integer bookId);
	public void addBook(Book book);
	public void updateBook(Book book);
	public void deleteBook(Book book);
	public void addBooks(List <Book> bookList);
	public void updateBooks(List <Book> bookList);
	public void deleteBooks(List <Book> bookList);
	
}
