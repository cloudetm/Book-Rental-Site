package com.r2r.orderedcart.service;

import java.util.List;

import com.r2r.orderedcart.model.OrderedCart;

public interface OrderedCartService {

	public void createOrderedCart(List <OrderedCart> oCart);
	public List <OrderedCart> getOrderedCartByOrderId(int orderId);
}
