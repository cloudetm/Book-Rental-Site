package com.r2r.book.model;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.r2r.order.model.Order;
import com.r2r.regis.model.Customer;


/**
 * The persistent class for the Book database table.
 * 
 */
@Entity
@Table(name="Book")
public class Book 
{
	
	@Id
	@Column(name="bookId")
	private int bookId;
    @Column(name="author")
	private String author;
    @Column(name="description")
	private String description;
    @Column(name="genre")
	private String genre;
    @Column(name="image")
	private String image;
    @Column(name="isbn")
	private String isbn;
    @Column(name="publishedOn")
	private String publishedOn;
    @Column(name="publisher")
	private String publisher;
    @Column(name="rating")
	private BigDecimal rating;
    @Column(name="status")
	private Boolean status;
    @Column(name="title")
	private String title;
  
    @ManyToMany(mappedBy = "cartBooks") 
    @JsonIgnore
    private List<Customer> cartCustomers;
    
    @ManyToMany(mappedBy = "wishlistBooks")  
    @JsonIgnore
    private List<Customer> wishlistCustomers;
    
    @ManyToMany(mappedBy = "booksOrderedCart") 
    @JsonIgnore
    private List<Order> orders;
    
	public int getBookId() {
		return this.bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getGenre() {
		return this.genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getImage() {
		return this.image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getIsbn() {
		return this.isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getPublishedOn() {
		return this.publishedOn;
	}

	public void setPublishedOn(String publishedOn) {
		this.publishedOn = publishedOn;
	}

	public String getPublisher() {
		return this.publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public BigDecimal getRating() {
		return this.rating;
	}

	public void setRating(BigDecimal rating) {
		this.rating = rating;
	}

	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(boolean b) {
		this.status = b;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@JsonIgnore
	public List<Customer> getCartCutomers(){
		return cartCustomers;
	}
	
	public void setCartCustomers(List<Customer> cartCustomers){
		this.cartCustomers = cartCustomers;
	}
	
	@JsonIgnore
	public List<Customer> getWishlistCustomers(){
		return wishlistCustomers;
	}
	
	public void setWishlistCustomers(List<Customer> wishlistCustomers){
		this.wishlistCustomers = wishlistCustomers;
	}

	public List<Order> getOrders(){
		return orders;
	}
	
	public void setOrders(List<Order> orders){
		this.orders = orders;
	}
}