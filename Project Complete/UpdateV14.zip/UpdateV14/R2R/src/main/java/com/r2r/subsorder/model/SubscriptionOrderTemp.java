package com.r2r.subsorder.model;

import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="SubscriptionOrderTemp")
public class SubscriptionOrderTemp {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "subsOrderId")
	private int subsOrderId;
	private boolean subsOrderStatus;
	private Long subsOrderDate;
	private String custEmail;
	private int subsId;
	public int getSubsOrderId() {
		return subsOrderId;
	}
	public void setSubsOrderId(int subsOrderId) {
		this.subsOrderId = subsOrderId;
	}
	public boolean isSubsOrderStatus() {
		return subsOrderStatus;
	}
	public void setSubsOrderStatus(boolean subsOrderStatus) {
		this.subsOrderStatus = subsOrderStatus;
	}
	public Long getSubsOrderDate() {
		return subsOrderDate;
	}
	public void setSubsOrderDate(Long subsOrderDate) {
		this.subsOrderDate = subsOrderDate;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public int getSubsId() {
		return subsId;
	}
	public void setSubsId(int subsId) {
		this.subsId = subsId;
	}
		
}
