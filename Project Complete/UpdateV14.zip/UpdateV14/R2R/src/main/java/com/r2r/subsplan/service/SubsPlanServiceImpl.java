package com.r2r.subsplan.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.r2r.subsplan.dao.SubsPlanDAO;
import com.r2r.subsplan.model.SubscriptionPlan;

public class SubsPlanServiceImpl implements SubsPlanService {

	
	private SubsPlanDAO subsPlanDAO;
	
	public void setSubsPlanDAO(SubsPlanDAO subsPlanDAO){
		this.subsPlanDAO = subsPlanDAO;
	}
	
	
	@Override
	@Transactional
	public void addPlans(List<SubscriptionPlan> subsPlanList) {
		this.subsPlanDAO.addPlans(subsPlanList);

	}

	@Override
	@Transactional
	public void updatePlans(List<SubscriptionPlan> subsPlanList){
		this.subsPlanDAO.updatePlans(subsPlanList);
	}
	
	@Override
	@Transactional
	public void deletePlans(List<SubscriptionPlan> subsPlanList){
		this.subsPlanDAO.deletePlans(subsPlanList);
	}
	
	@Override
	@Transactional
	public List<SubscriptionPlan> getAll() {
		return this.subsPlanDAO.getAll();
	}

	@Override
	@Transactional
	public SubscriptionPlan getPlanById(int subsId){
		return this.subsPlanDAO.getPlanById(subsId);
	}
}
