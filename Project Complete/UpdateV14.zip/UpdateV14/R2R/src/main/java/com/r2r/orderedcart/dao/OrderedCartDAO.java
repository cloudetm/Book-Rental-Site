package com.r2r.orderedcart.dao;

import java.util.List;

import com.r2r.orderedcart.model.OrderedCart;

public interface OrderedCartDAO {

	public void createOrderedCart(List <OrderedCart> oCart);
	public List <OrderedCart> getOrderedCartByOrderId(int orderId);
}
