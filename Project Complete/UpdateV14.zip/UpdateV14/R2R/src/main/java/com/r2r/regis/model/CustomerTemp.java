package com.r2r.regis.model;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
@Table(name="CustomerTemp")
public class CustomerTemp {
	
	@Id 
	@Column(name="custEmail")
	private String custEmail;
	private String custFirstName;
	private String custMiddleName;
	private String custLastName;
	private String custDOB;
	private String custAddress;
	private String custCity;
	private String custState;
	private Long custPincode;
	private Long custMobileNo;
	private String custLanguage;
	private String custPassword;
	private Long custRegDate;
	private String custPasskey;
	private Boolean custIsVerified;
	private int subsId;
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public String getCustFirstName() {
		return custFirstName;
	}
	public void setCustFirstName(String custFirstName) {
		this.custFirstName = custFirstName;
	}
	public String getCustMiddleName() {
		return custMiddleName;
	}
	public void setCustMiddleName(String custMiddleName) {
		this.custMiddleName = custMiddleName;
	}
	public String getCustLastName() {
		return custLastName;
	}
	public void setCustLastName(String custLastName) {
		this.custLastName = custLastName;
	}
	public String getCustDOB() {
		return custDOB;
	}
	public void setCustDOB(String custDOB) {
		this.custDOB = custDOB;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public String getCustCity() {
		return custCity;
	}
	public void setCustCity(String custCity) {
		this.custCity = custCity;
	}
	public String getCustState() {
		return custState;
	}
	public void setCustState(String custState) {
		this.custState = custState;
	}
	public Long getCustPincode() {
		return custPincode;
	}
	public void setCustPincode(Long custPincode) {
		this.custPincode = custPincode;
	}
	public Long getCustMobileNo() {
		return custMobileNo;
	}
	public void setCustMobileNo(Long custMobileNo) {
		this.custMobileNo = custMobileNo;
	}
	public String getCustLanguage() {
		return custLanguage;
	}
	public void setCustLanguage(String custLanguage) {
		this.custLanguage = custLanguage;
	}
	public String getCustPassword() {
		return custPassword;
	}
	public void setCustPassword(String custPassword) {
		this.custPassword = custPassword;
	}
	public Long getCustRegDate() {
		return custRegDate;
	}
	public void setCustRegDate(Long custRegDate) {
		this.custRegDate = custRegDate;
	}
	public String getCustPasskey() {
		return custPasskey;
	}
	public void setCustPasskey(String custPasskey) {
		this.custPasskey = custPasskey;
	}
	public Boolean getCustIsVerified() {
		return custIsVerified;
	}
	public void setCustIsVerified(Boolean custIsVerified) {
		this.custIsVerified = custIsVerified;
	}
	public int getSubsId() {
		return subsId;
	}
	public void setSubsId(int subsId) {
		this.subsId = subsId;
	}
	

}

