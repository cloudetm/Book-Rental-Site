package com.r2r.subsorder.model;

import java.io.Serializable;
import javax.persistence.*;

import com.r2r.regis.model.Customer;
import com.r2r.subsplan.model.SubscriptionPlan;



/**
 * The persistent class for the SubscriptionOrder database table.
 * 
 */
@Entity
public class SubscriptionOrder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int subsOrderId;

	private Long subsOrderDate;

	private Boolean subsOrderStatus;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="custEmail")
	private Customer customer;

	//bi-directional many-to-one association to SubscriptionPlan
	@ManyToOne
	@JoinColumn(name="subsId")
	private SubscriptionPlan subscriptionPlan;

	public SubscriptionOrder() {
	}

	public int getSubsOrderId() {
		return this.subsOrderId;
	}

	public void setSubsOrderId(int subsOrderId) {
		this.subsOrderId = subsOrderId;
	}

	public Long getSubsOrderDate() {
		return this.subsOrderDate;
	}

	public void setSubsOrderDate(Long subsOrderDate) {
		this.subsOrderDate = subsOrderDate;
	}

	public Boolean getSubsOrderStatus() {
		return this.subsOrderStatus;
	}

	public void setSubsOrderStatus(Boolean subsOrderStatus) {
		this.subsOrderStatus = subsOrderStatus;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public SubscriptionPlan getSubscriptionPlan() {
		return this.subscriptionPlan;
	}

	public void setSubscriptionPlan(SubscriptionPlan subscriptionPlan) {
		this.subscriptionPlan = subscriptionPlan;
	}

}