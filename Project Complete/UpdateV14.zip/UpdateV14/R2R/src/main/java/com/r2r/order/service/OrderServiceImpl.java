package com.r2r.order.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.r2r.order.dao.OrderDAO;
import com.r2r.order.model.Order;
import com.r2r.wishlist.dao.WishlistDAO;

public class OrderServiceImpl implements OrderService {

	
	private OrderDAO orderDAO;
	
	public void setOrderDAO(OrderDAO orderDAO){
		this.orderDAO = orderDAO;
	}
	
	@Override
	@Transactional
	public void createOrder(Order o) {
		this.orderDAO.createOrder(o);

	}

	@Override
	@Transactional
	public Order getOrderByCustIdAndStatus(String cust_email, String status) {
		return this.orderDAO.getOrderByCustIdAndStatus(cust_email, status);
	}

	@Override
	@Transactional
	public void updateOrder(Order o) {
		this.orderDAO.updateOrder(o);

	}

	@Override
	@Transactional
	public List<Order> getAllById(String cust_email) {
		return this.orderDAO.getAllById(cust_email);
	}

	@Override
	@Transactional
	public List<Order> getOrderByStatus(String status) {
		return this.getOrderByStatus(status);
	}

	@Override
	@Transactional
	public List<Order> getAll() {
		return this.orderDAO.getAll();
	}

	@Override
	@Transactional
	public List<Order> getAllBetweenDate(Long dateFrom, Long dateTill){
		return this.getAllBetweenDate(dateFrom, dateTill);
	}
}
