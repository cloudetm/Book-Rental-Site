package com.r2r.subsorder.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.r2r.subsorder.model.SubscriptionOrder;

@Repository
public class SubsOrderDAOImpl implements SubsOrderDAO {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	@Override
	public void generateSubsOrder(SubscriptionOrder subsOrder){
		Session session = this.sessionFactory.getCurrentSession();
		session.save(subsOrder);
	}
	
	@Override
	public List <SubscriptionOrder> getSubsOrder(Boolean subsOrderStatus){
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM SubscriptionOrder SO WHERE SO.subsOrderStatus = :subsOrderStatus";
		Query query = session.createQuery(hql);
		query.setParameter("subsOrderStatus", subsOrderStatus);
		List <SubscriptionOrder> subsOrderList = query.list();
		return subsOrderList;
	}
	
	@Override
	public void updateSubsOrder(SubscriptionOrder subsOrder){
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(subsOrder);
	}
	
	@Override
	public List <SubscriptionOrder> getMySubsOrder(String custEmail){
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM SubscriptionOrder SO WHERE SO.custEmail = :custEmail";
		Query query = session.createQuery(hql);
		query.setParameter("custEmail", custEmail);
		List <SubscriptionOrder> subsOrderList = query.list();
		return subsOrderList;
	}
	
	@Override 
	public SubscriptionOrder getActiveSubsOrder(String custEmail){
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM SubscriptionOrder SO WHERE SO.custEmail = :custEmail AND SO.subsOrderStatus = true";
		Query query = session.createQuery(hql);
		query.setParameter("custEmail", custEmail);
		SubscriptionOrder subsOrder = (SubscriptionOrder) query.uniqueResult();
		return subsOrder;
	}
}
