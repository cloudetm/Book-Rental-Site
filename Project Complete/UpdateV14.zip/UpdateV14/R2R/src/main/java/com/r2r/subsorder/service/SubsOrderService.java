package com.r2r.subsorder.service;

import java.util.List;

import com.r2r.subsorder.model.SubscriptionOrder;

public interface SubsOrderService {

	public void generateSubsOrder(SubscriptionOrder subsOrder);
	public List <SubscriptionOrder> getSubsOrder(Boolean subs_order_status);
	public void updateSubsOrder(SubscriptionOrder subsOrder);
	public List <SubscriptionOrder> getMySubsOrder(String cust_email);
	public SubscriptionOrder getActiveSubsOrder(String cust_email);
}
