package com.r2r.wishlist.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.r2r.subsplan.dao.SubsPlanDAO;
import com.r2r.wishlist.dao.WishlistDAO;
import com.r2r.wishlist.model.Wishlist;

public class WishlistServiceImpl implements WishlistService {

	private WishlistDAO wishlistDAO;
	
	public void setWishlistDAO(WishlistDAO wishlistDAO){
		this.wishlistDAO = wishlistDAO;
	}
	
	@Override
	@Transactional
	public void addItem(Wishlist w) {
		this.wishlistDAO.addItem(w);

	}

	@Override
	@Transactional
	public void deleteItem(Wishlist w) {
		this.wishlistDAO.deleteItem(w);

	}

	@Override
	@Transactional
	public void removeAll(String cust_email) {
		this.wishlistDAO.removeAll(cust_email);
	}

	@Override
	@Transactional
	public List<Wishlist> getAll(String cust_email) {
		return this.wishlistDAO.getAll(cust_email);
	}

}
