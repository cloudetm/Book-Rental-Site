package com.r2r.regis.model;

import java.io.Serializable;
import javax.persistence.*;

import com.r2r.book.model.Book;
import com.r2r.order.model.Order;
import com.r2r.subsorder.model.SubscriptionOrder;


import java.util.Date;
import java.util.List;


/**
 * The persistent class for the Customer database table.
 * 
 */
@Entity
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String custEmail;

	@Lob
	private String custAddress;

	private String custCity;

	private String custCountry;

	@Temporal(TemporalType.DATE)
	private Date custDOB;

	private String custFirstName;

	private Boolean custIsVerified;

	private String custLanguage;

	private String custLastName;

	private String custMiddleName;

	private Long custMobileNo;

	private String custPasskey;

	private String custPassword;

	private Long custPincode;

	private Long custRegDate;

	private String custState;

	//bi-directional many-to-many association to Book
	@ManyToMany(mappedBy="customers1")
	private List<Book> books1;

	//bi-directional many-to-many association to Book
	@ManyToMany(mappedBy="customers2")
	private List<Book> books2;

	//bi-directional many-to-one association to Order
	@OneToMany(mappedBy="customer")
	private List<Order> orders;

	//bi-directional many-to-one association to SubscriptionOrder
	@OneToMany(mappedBy="customer")
	private List<SubscriptionOrder> subscriptionOrders;

	public Customer() {
	}

	public String getCustEmail() {
		return this.custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public String getCustAddress() {
		return this.custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public String getCustCity() {
		return this.custCity;
	}

	public void setCustCity(String custCity) {
		this.custCity = custCity;
	}

	public String getCustCountry() {
		return this.custCountry;
	}

	public void setCustCountry(String custCountry) {
		this.custCountry = custCountry;
	}

	public Date getCustDOB() {
		return this.custDOB;
	}

	public void setCustDOB(Date custDOB) {
		this.custDOB = custDOB;
	}

	public String getCustFirstName() {
		return this.custFirstName;
	}

	public void setCustFirstName(String custFirstName) {
		this.custFirstName = custFirstName;
	}

	public Boolean getCustIsVerified() {
		return this.custIsVerified;
	}

	public void setCustIsVerified(Boolean custIsVerified) {
		this.custIsVerified = custIsVerified;
	}

	public String getCustLanguage() {
		return this.custLanguage;
	}

	public void setCustLanguage(String custLanguage) {
		this.custLanguage = custLanguage;
	}

	public String getCustLastName() {
		return this.custLastName;
	}

	public void setCustLastName(String custLastName) {
		this.custLastName = custLastName;
	}

	public String getCustMiddleName() {
		return this.custMiddleName;
	}

	public void setCustMiddleName(String custMiddleName) {
		this.custMiddleName = custMiddleName;
	}

	public Long getCustMobileNo() {
		return this.custMobileNo;
	}

	public void setCustMobileNo(Long custMobileNo) {
		this.custMobileNo = custMobileNo;
	}

	public String getCustPasskey() {
		return this.custPasskey;
	}

	public void setCustPasskey(String custPasskey) {
		this.custPasskey = custPasskey;
	}

	public String getCustPassword() {
		return this.custPassword;
	}

	public void setCustPassword(String custPassword) {
		this.custPassword = custPassword;
	}

	public Long getCustPincode() {
		return this.custPincode;
	}

	public void setCustPincode(Long custPincode) {
		this.custPincode = custPincode;
	}

	public Long getCustRegDate() {
		return this.custRegDate;
	}

	public void setCustRegDate(Long custRegDate) {
		this.custRegDate = custRegDate;
	}

	public String getCustState() {
		return this.custState;
	}

	public void setCustState(String custState) {
		this.custState = custState;
	}

	public List<Book> getBooks1() {
		return this.books1;
	}

	public void setBooks1(List<Book> books1) {
		this.books1 = books1;
	}

	public List<Book> getBooks2() {
		return this.books2;
	}

	public void setBooks2(List<Book> books2) {
		this.books2 = books2;
	}

	public List<Order> getOrders() {
		return this.orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public Order addOrder(Order order) {
		getOrders().add(order);
		order.setCustomer(this);

		return order;
	}

	public Order removeOrder(Order order) {
		getOrders().remove(order);
		order.setCustomer(null);

		return order;
	}

	public List<SubscriptionOrder> getSubscriptionOrders() {
		return this.subscriptionOrders;
	}

	public void setSubscriptionOrders(List<SubscriptionOrder> subscriptionOrders) {
		this.subscriptionOrders = subscriptionOrders;
	}

	public SubscriptionOrder addSubscriptionOrder(SubscriptionOrder subscriptionOrder) {
		getSubscriptionOrders().add(subscriptionOrder);
		subscriptionOrder.setCustomer(this);

		return subscriptionOrder;
	}

	public SubscriptionOrder removeSubscriptionOrder(SubscriptionOrder subscriptionOrder) {
		getSubscriptionOrders().remove(subscriptionOrder);
		subscriptionOrder.setCustomer(null);

		return subscriptionOrder;
	}

}