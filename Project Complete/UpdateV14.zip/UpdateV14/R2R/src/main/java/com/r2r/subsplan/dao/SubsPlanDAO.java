package com.r2r.subsplan.dao;

import java.util.List;

import com.r2r.subsplan.model.SubscriptionPlan;

public interface SubsPlanDAO {
	
	public void addPlans(List<SubscriptionPlan> subsPlanList);
	public void updatePlans(List<SubscriptionPlan> subsPlanList);
	public void deletePlans(List<SubscriptionPlan> subsPlanList);
	public List<SubscriptionPlan> getAll();
	public SubscriptionPlan getPlanById(int subsId);
	
}
