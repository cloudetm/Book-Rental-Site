package com.r2r.order.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.r2r.order.model.Order;
import com.r2r.subsorder.model.SubscriptionOrder;

@Repository
public class OrderDAOImpl implements OrderDAO {

	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	@Override
	public void createOrder(Order o) {
		Session session = this.sessionFactory.getCurrentSession();
		session.save(o);

	}

	@Override
	public Order getOrderByCustIdAndStatus(String cust_email, String status) {
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM Order O WHERE O.cust_email = :cust_email AND O.status = :status";
		Query query = session.createQuery(hql);
		query.setParameter("cust_email", cust_email);
		query.setParameter("status", status);
		List <Order> orderList = query.list();
		Order order = new Order();
		for(Order ol : orderList){
			order = ol;
		}
		return order;
	}

	@Override
	public void updateOrder(Order o) {
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(o);
	}

	@Override
	public List<Order> getAllById(String cust_email) {
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM Order O WHERE O.cust_email = :cust_email";
		Query query = session.createQuery(hql);
		query.setParameter("cust_email", cust_email);
		List <Order> orderList = query.list();
		return orderList;
	}

	@Override
	public List<Order> getOrderByStatus(String status) {
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM Order O WHERE O.status = :status";
		Query query = session.createQuery(hql);
		query.setParameter("status", status);
		List <Order> orderList = query.list();
		return orderList;
	}

	@Override
	public List<Order> getAll() {
		Session session = this.sessionFactory.getCurrentSession();
		List <Order> orderList = session.createQuery("FROM Order").list();
		return orderList;
	}

	@Override
	public List<Order> getAllBetweenDate(Long dateFrom, Long dateTill){
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM Order O WHERE O.order_date BETWEEN :dateFrom, :dateTill";
		Query query = session.createQuery(hql);
		query.setParameter("dateFrom", dateFrom);
		query.setParameter("dateTill",  dateTill);
		List<Order> orderList = query.list();
		return orderList;
	}
}
