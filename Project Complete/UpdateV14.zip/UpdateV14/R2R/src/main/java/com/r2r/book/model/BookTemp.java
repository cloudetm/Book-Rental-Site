package com.r2r.book.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="BookTemp")
public class BookTemp {
	
	@Id 
	@Column(name="bookId")
	private int bookId;
	private String title;
	private String isbn;
	private String description;
	private Float rating;
	private String author;
	private String image;
	private String genre;
	private String publishedOn;
	private String publisher;
	private Boolean status;
	
	public int getBookId() {
		return bookId;
	}
	public void setBookid(int bookId) {
		this.bookId = bookId;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getIsbn() {
		return isbn;
	}	
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getDescription() {
		return description;
	}
	public void setDescripiton(String description) {
		this.description = description;
	}
	
	public Float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	public String getGenre(){
		return genre;
	}
	public void setGenre(String genre){
		this.genre = genre;
	}
	
	public String getPublishedOn(){
		return publishedOn;
	}
	public void setPublishedOn(String publishedOn){
		this.publishedOn = publishedOn;
	}
	
	public String getPublisher(){
		return publisher;
	}
	public void setPublisher(String publisher){
		this.publisher = publisher;
	}
	
	public Boolean getStatus(){
		return status;
	}
	public void setStatus(Boolean status){
		this.status = status;
	}
}
