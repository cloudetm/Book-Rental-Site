package com.r2r.controller;

public class MainControllerURIConstant {
	
	public static final String HOME = "/home";
	public static final String UPLOAD_PLANS_HTML = "/uploads/plans";
	public static final String UPLOAD_BOOKS_HTML = "/uploads/books";
		
	public static final String GET_ALL_CUSTOMERS = "/customers";
	public static final String REGISTER_CUSTOMER = "/register";
	public static final String UPDATE_ADDRESS = "/update";
	public static final String VERIFY_EMAIL = "/verify";
	
	public static final String LOGIN = "/login";
	public static final String FORGOT_PASSWORD = "/forget";
	public static final String CHANGE_PASSWORD = "/forget/change";
	
	public static final String ADD_PLANS = "/plans/add";
	public static final String UPDATE_PLANS = "/plans/update";
	public static final String DELETE_PLANS = "/plans/delete";
	public static final String GET_ALL_PLANS = "/subplans";
	
	public static final String GET_ALL_BOOKS = "/books/all";   			//operator can see all books
	public static final String SEARCH_BOOKS = "/books/search"; 			//search used by user and operator
	public static final String GET_BOOK_BY_ID = "/book/get";   			//get book by id used by user
	public static final String ADD_BOOK = "/book/add"; 					//single book added by operator
	public static final String UPDATE_BOOK_BY_ID = "/book/update";		//single book update by operator
	public static final String DELETE_BOOK_BY_ID = "/book/delete";		//single book deleted by operator
	public static final String ADD_BOOKS_FROM_CSV = "/books/add";		//add multiple from csv
	public static final String UPDATE_BOOKS_FROM_CSV = "/books/update";	//update multiple from csv
	public static final String DELETE_BOOKS_FROM_CSV = "/books/delete"; //delete multiple from csv
	
	public static final String SUBSCRIBE_PLAN = "/myplan";
	public static final String ACTIVE_SUBSCRIPTIONS = "/active/subscriptions";
	public static final String NONACTIVE_SUBSCRIPTIONS = "/nonactive/subscriptions";
	public static final String MY_SUBSCRIPTIONS = "/my/subscriptions";
	
	public static final String ADD_TO_WISHLIST = "/wishlist/add";
	public static final String REMOVE_FROM_WISHLIST = "/wishlist/remove";
	public static final String REMOVE_ALL_WISHLIST = "/wishlist/empty";
	public static final String GET_ALL_FROM_WISHLIST = "/wishlist/getall";
	
	public static final String ADD_ITEM_TO_CART = "/cart/add";
	public static final String GET_ALL_FROM_CART = "/cart/getall";
	public static final String REMOVE_ITEM = "/cart/remove";
	public static final String EMPTY_CART = "/cart/empty";
	
	public static final String CHECKOUT = "/checkout";
	public static final String MY_ORDERS = "/myorders";
	public static final String CANCEL_MY_ORDER = "/order/cancel";
	public static final String PENDING_ORDERS = "/orders/pending";
	public static final String COMPLETE_ORDERS = "/orders/complete";
	public static final String RETURN = "/return";
	public static final String CANCEL_RETURN = "/return/cancel";
	public static final String PENDING_RETURNS = "/returns/pending";
	public static final String COMPLETE_RETURNS = "/returns/complete";
	public static final String ALL_ORDERS = "/orders/all";
	
	public static final String ORDERED_ITEMS = "/ordered/items";
	
	public static final String ALL_RENTED = "/report/rented";
	public static final String RENTED_BY_AUTHOR_NAME = "/report/author";
	public static final String RENTED_BY_GENRE_NAME = "/report/genre";
}
