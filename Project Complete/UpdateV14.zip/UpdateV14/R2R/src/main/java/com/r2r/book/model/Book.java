package com.r2r.book.model;

import java.io.Serializable;
import javax.persistence.*;

import com.r2r.regis.model.Customer;

import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the Book database table.
 * 
 */
@Entity
public class Book implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int bookId;

	private String author;

	private String description;

	private String genre;

	private String image;

	private String isbn;

	private String publishedOn;

	private String publisher;

	private Float rating;

	private Boolean status;

	private String title;

	//bi-directional many-to-many association to Customer
	@ManyToMany
	@JoinTable(
		name="Cart"
		, joinColumns={
			@JoinColumn(name="bookId")
			}
		, inverseJoinColumns={
			@JoinColumn(name="custEmail")
			}
		)
	private List<Customer> customers1;

	//bi-directional many-to-many association to Customer
	@ManyToMany
	@JoinTable(
		name="Wishlist"
		, joinColumns={
			@JoinColumn(name="bookId")
			}
		, inverseJoinColumns={
			@JoinColumn(name="custEmail")
			}
		)
	private List<Customer> customers2;

	public Book() {
	}

	public int getBookId() {
		return this.bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getGenre() {
		return this.genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getImage() {
		return this.image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getIsbn() {
		return this.isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getPublishedOn() {
		return this.publishedOn;
	}

	public void setPublishedOn(String publishedOn) {
		this.publishedOn = publishedOn;
	}

	public String getPublisher() {
		return this.publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public Float getRating() {
		return this.rating;
	}

	public void setRating(Float rating) {
		this.rating = rating;
	}

	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) { 
		this.title = title;
	}

	public List<Customer> getCustomers1() {
		return this.customers1;
	}

	public void setCustomers1(List<Customer> customers1) {
		this.customers1 = customers1;
	}

	public List<Customer> getCustomers2() {
		return this.customers2;
	}

	public void setCustomers2(List<Customer> customers2) {
		this.customers2 = customers2;
	}

}