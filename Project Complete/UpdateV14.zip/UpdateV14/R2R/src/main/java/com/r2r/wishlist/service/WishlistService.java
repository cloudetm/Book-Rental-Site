package com.r2r.wishlist.service;

import java.util.List;

import com.r2r.wishlist.model.Wishlist;

public interface WishlistService {

	public void addItem(Wishlist w);
	public void deleteItem(Wishlist w);
	public void removeAll(String cust_email);
	public List<Wishlist> getAll(String cust_email);
	
}
