package com.r2r.regis.dao;

import java.util.List;

import com.r2r.regis.model.Customer;

public interface CustomerDAO {
	
	public void addCustomer(Customer c);
	public void updateCustomer(Customer c);
	public List<Customer> listCustomers();
	public Customer getCustomerByPasskey(String passkey);
	public Customer getCustomerById(String emailId);
	public void removeCustomer(String emailId);
	
}
