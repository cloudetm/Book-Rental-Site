package com.r2r.orderedcart.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the OrderedCart database table.
 * 
 */
@Entity
public class OrderedCart implements Serializable {
	private static final long serialVersionUID = 1L;

	private int bookId;

	private int orderId;

	public OrderedCart() {
	}

	public int getBookId() {
		return this.bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public int getOrderId() {
		return this.orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

}