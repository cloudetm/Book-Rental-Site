package com.r2r.book.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.r2r.book.dao.BookDAO;
import com.r2r.book.model.Book;

public class BookServiceImpl implements BookService {

	
	private BookDAO bookDAO;
	
	public void setBookDAO(BookDAO bookDAO){
		this.bookDAO = bookDAO;
	}
	
	
	@Override
	@Transactional
	public Book getById(Integer bookId) {
		Book book = this.bookDAO.getById(bookId);
		return book;
	}

	@Override
	@Transactional
	public List<Book> getAll() {
		return this.bookDAO.getAll();
	}
	
	@Override
	@Transactional
	public void addBook(Book book){
		this.bookDAO.addBook(book);
	}
	
	@Override
	@Transactional
	public void updateBook(Book book){
		this.bookDAO.updateBook(book);
	}
	
	@Override
	@Transactional
	public void deleteBook(Book book){
		this.bookDAO.deleteBook(book);
	}
	
	@Override
	@Transactional
	public void addBooks(List <Book> bookList){
		this.bookDAO.addBooks(bookList);
	}
	
	@Override
	@Transactional
	public void updateBooks(List <Book> bookList){
		this.bookDAO.updateBooks(bookList);
	}
	
	@Override
	@Transactional
	public void deleteBooks(List <Book> bookList){
		this.bookDAO.deleteBooks(bookList);
	}

}
