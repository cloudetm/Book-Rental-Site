package com.r2r.subsplan.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="SubscriptionPlanTemp")
public class SubscriptionPlanTemp {
	
	
	@Id 
	@Column(name="subsId")
	private int subsId;
	private String subsName;
	private int subsPerDelivery;
	private int subsDuration;
	private int subsDeliveries;
	private int subsTotalBooks;
	private int subsMembershipFee;
	private int subsDeliveryCharges;
	private int subsRefundableSecurity;
	private int subsSubscriptionFee;
	private String subsSuitableFor;
	private int subsMaxMagzines;
	public int getSubsId() {
		return subsId;
	}
	public void setSubsId(int subsId) {
		this.subsId = subsId;
	}
	public String getSubsName() {
		return subsName;
	}
	public void setSubsName(String subsName) {
		this.subsName = subsName;
	}
	public int getSubsPerDelivery() {
		return subsPerDelivery;
	}
	public void setSubsPerDelivery(int subsPerDelivery) {
		this.subsPerDelivery = subsPerDelivery;
	}
	public int getSubsDuration() {
		return subsDuration;
	}
	public void setSubsDuration(int subsDuration) {
		this.subsDuration = subsDuration;
	}
	public int getSubsDeliveries() {
		return subsDeliveries;
	}
	public void setSubsDeliveries(int subsDeliveries) {
		this.subsDeliveries = subsDeliveries;
	}
	public int getSubsTotalBooks() {
		return subsTotalBooks;
	}
	public void setSubsTotalBooks(int subsTotalBooks) {
		this.subsTotalBooks = subsTotalBooks;
	}
	public int getSubsMembershipFee() {
		return subsMembershipFee;
	}
	public void setSubsMembershipFee(int subsMembershipFee) {
		this.subsMembershipFee = subsMembershipFee;
	}
	public int getSubsDeliveryCharges() {
		return subsDeliveryCharges;
	}
	public void setSubsDeliveryCharges(int subsDeliveryCharges) {
		this.subsDeliveryCharges = subsDeliveryCharges;
	}
	public int getSubsRefundableSecurity() {
		return subsRefundableSecurity;
	}
	public void setSubsRefundableSecurity(int subsRefundableSecurity) {
		this.subsRefundableSecurity = subsRefundableSecurity;
	}
	public int getSubsSubscriptionFee() {
		return subsSubscriptionFee;
	}
	public void setSubsSubscriptionFee(int subsSubscriptionFee) {
		this.subsSubscriptionFee = subsSubscriptionFee;
	}
	public String getSubsSuitableFor() {
		return subsSuitableFor;
	}
	public void setSubsSuitableFor(String subsSuitableFor) {
		this.subsSuitableFor = subsSuitableFor;
	}
	public int getSubsMaxMagzines() {
		return subsMaxMagzines;
	}
	public void setSubsMaxMagzines(int subsMaxMagzines) {
		this.subsMaxMagzines = subsMaxMagzines;
	}
	
	
}
