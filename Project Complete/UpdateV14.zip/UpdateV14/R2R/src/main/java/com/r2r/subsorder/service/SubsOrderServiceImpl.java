package com.r2r.subsorder.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.r2r.subsorder.dao.SubsOrderDAO;
import com.r2r.subsorder.model.SubscriptionOrder;

public class SubsOrderServiceImpl implements SubsOrderService {

	
	private SubsOrderDAO subsOrderDAO;
	
	public void setSubsOrderDAO(SubsOrderDAO subsOrderDAO){
		this.subsOrderDAO = subsOrderDAO;
	}
	
	
	@Override
	@Transactional
	public void generateSubsOrder(SubscriptionOrder subsOrder) {
		this.subsOrderDAO.generateSubsOrder(subsOrder);

	}

	@Override
	@Transactional
	public List<SubscriptionOrder> getSubsOrder(Boolean subs_order_status) {
		return this.subsOrderDAO.getSubsOrder(subs_order_status);
	}

	@Override
	@Transactional
	public void updateSubsOrder(SubscriptionOrder subsOrder) {
		this.subsOrderDAO.updateSubsOrder(subsOrder);

	}
	
	@Override
	@Transactional
	public List <SubscriptionOrder> getMySubsOrder(String cust_email){
		return this.subsOrderDAO.getMySubsOrder(cust_email);
	}

	@Override
	@Transactional
	public SubscriptionOrder getActiveSubsOrder(String cust_email){
		return this.subsOrderDAO.getActiveSubsOrder(cust_email);
	}
}
