package com.r2r.cart.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.r2r.cart.model.Cart;
import com.r2r.subsorder.model.SubscriptionOrder;


@Repository
public class CartDAOImpl implements CartDAO {

	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	@Override
	public void addItemToCart(Cart c){
		Session session = this.sessionFactory.getCurrentSession();
		session.save(c);
	}
	
	@Override
	public List <Cart> getAll(String cust_email){
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM Cart C WHERE C.cust_email = :cust_email";
		Query query = session.createQuery(hql);
		query.setParameter("cust_email", cust_email);
		List <Cart> cartList = query.list();
		return cartList;
	}
	
	@Override
	public void removeItem(Cart c){
		Session session = this.sessionFactory.getCurrentSession();
		session.delete(c);
	}
	
	@Override
	public void emptyCart(String cust_email){
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "DELETE FROM Cart C WHERE C.cust_email = :cust_email";
		Query query = session.createQuery(hql);
		query.setParameter("cust_email", cust_email);
		query.executeUpdate();
	}
}
