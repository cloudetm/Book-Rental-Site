package com.r2r.cart.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.r2r.cart.dao.CartDAO;
import com.r2r.cart.model.Cart;
import com.r2r.subsorder.dao.SubsOrderDAO;

public class CartServiceImpl implements CartService {

	
	
	private CartDAO cartDAO;
	
	public void setCartDAO(CartDAO cartDAO){
		this.cartDAO = cartDAO;
	}
	
	@Override
	@Transactional
	public void addItemToCart(Cart c) {
		this.cartDAO.addItemToCart(c);

	}

	@Override
	@Transactional
	public List<Cart> getAll(String cust_email) {
		return this.getAll(cust_email);
	}

	@Override
	@Transactional
	public void removeItem(Cart c) {
		this.cartDAO.removeItem(c);

	}

	@Override
	@Transactional
	public void emptyCart(String cust_email) {
		this.cartDAO.emptyCart(cust_email);

	}

}
