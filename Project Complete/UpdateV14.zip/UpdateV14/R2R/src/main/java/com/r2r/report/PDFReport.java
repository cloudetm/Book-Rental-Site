package com.r2r.report;

import java.io.IOException;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.PDFont;

import com.r2r.book.model.Book;

public class PDFReport {
    public String pdfReportGenerate(String reportId, String  reportTitle, String reportPeriod, String filter, List<Book> bookList) throws Exception {
        
    	PDDocument document = new PDDocument();
    	PDPage page1 = new PDPage(PDPage.PAGE_SIZE_A4);
    	
    	PDRectangle rect = page1.getMediaBox();
    	
    	document.addPage(page1);
    	
    	PDFont fontBold = PDType1Font.HELVETICA_BOLD;
    	PDFont fontMono = PDType1Font.COURIER;
    	
    	PDPageContentStream cos = new PDPageContentStream(document, page1);

    	int line = 0;
 
    	cos.beginText();
        cos.setFont(fontBold, 12);
        cos.moveTextPositionByAmount(100, rect.getHeight() - 50*(++line));
        cos.drawString("RENT2READ Report");
        cos.endText();
        
        cos.beginText();
        cos.setFont(fontBold, 12);
        cos.moveTextPositionByAmount(100, rect.getHeight() - 20*(++line));
        cos.drawString("ReportID : " + reportId);
        cos.endText();
        
        cos.beginText();
        cos.setFont(fontBold, 12);
        cos.moveTextPositionByAmount(100, rect.getHeight() - 20*(++line));
        cos.drawString("Report Title : " + reportTitle);
        cos.endText();
        
        cos.beginText();
        cos.setFont(fontBold, 12);
        cos.moveTextPositionByAmount(100, rect.getHeight() - 20*(++line));
        cos.drawString("For Period : " + reportPeriod);
        cos.endText();
        
        cos.beginText();
        cos.setFont(fontBold, 12);
        cos.moveTextPositionByAmount(100, rect.getHeight() - 20*(++line));
        cos.drawString("Filter : " + filter);
        cos.endText();
        
        cos.beginText();
        cos.setFont(fontBold, 12);
        cos.moveTextPositionByAmount(100, rect.getHeight() - 20*(++line));
        cos.drawString("Report:");
        cos.endText();
        
        cos.beginText();
        cos.setFont(fontBold, 12);
        cos.moveTextPositionByAmount(100, rect.getHeight() - 20*(++line));
        cos.drawString("BookId           Title                Rating            Author             Genre");
        cos.endText();
        
        for(Book book : bookList){
        	cos.beginText();
            cos.setFont(fontMono, 12);
            cos.moveTextPositionByAmount(100, rect.getHeight() - 10*(++line));
            cos.drawString(book.getBookId()+ " " + book.getTitle() + " " + book.getRating() + " " + book.getAuthor() + " " + book.getGenre());
            cos.endText();
        }
        
        cos.close();
        
        String reportFileName = "Report" + reportId + ".pdf";
        document.save("src/main/webapp/WEB-INF/reports/" + reportFileName);
        document.close();
        
        return reportFileName;
}
}