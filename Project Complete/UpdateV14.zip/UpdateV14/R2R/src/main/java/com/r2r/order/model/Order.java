package com.r2r.order.model;

import java.io.Serializable;
import javax.persistence.*;

import com.r2r.regis.model.Customer;

import java.math.BigInteger;


/**
 * The persistent class for the Order database table.
 * 
 */
@Entity
public class Order implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int orderId;

	private BigInteger orderDate;

	private String status;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="custEmail")
	private Customer customer;

	public Order() {
	}

	public int getOrderId() {
		return this.orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public BigInteger getOrderDate() {
		return this.orderDate;
	}

	public void setOrderDate(BigInteger orderDate) {
		this.orderDate = orderDate;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}