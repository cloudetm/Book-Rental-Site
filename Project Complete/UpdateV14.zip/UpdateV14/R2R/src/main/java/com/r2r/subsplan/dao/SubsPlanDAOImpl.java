package com.r2r.subsplan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.r2r.cart.model.Cart;
import com.r2r.regis.model.Customer;
import com.r2r.subsplan.dao.SubsPlanDAO;
import com.r2r.subsplan.model.SubscriptionPlan;

@Repository
public class SubsPlanDAOImpl implements SubsPlanDAO {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	@Override
	public void addPlans(List<SubscriptionPlan> subsPlanList) {
		Session session = this.sessionFactory.getCurrentSession();
		for(SubscriptionPlan sPlan : subsPlanList){
			session.save(sPlan);
			session.flush();
		}
    }
	
	@Override
	public void updatePlans(List<SubscriptionPlan> subsPlanList){
		Session session = this.sessionFactory.getCurrentSession();
		for(SubscriptionPlan sPlan : subsPlanList){
			session.saveOrUpdate(sPlan);
			session.flush();
		}
		
		
	}
	
	@Override
	public void deletePlans(List<SubscriptionPlan> subsPlanList){
		Session session = this.sessionFactory.getCurrentSession();
		for(SubscriptionPlan sPlan : subsPlanList){
			session.delete(sPlan);
			session.flush();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<SubscriptionPlan> getAll(){
		Session session = this.sessionFactory.getCurrentSession();
		List<SubscriptionPlan> subsPlanList = session.createQuery("from SubscriptionPlan").list();
		return subsPlanList;
	}
	
	@Override
	public SubscriptionPlan getPlanById(int subsId){
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM SubscriptionPlan S WHERE S.subsId = :subsId";
		Query query = session.createQuery(hql);
		query.setParameter("subsId", subsId);
		List <SubscriptionPlan> subsPlanList = query.list();
		SubscriptionPlan subsPlan = new SubscriptionPlan();
		for(SubscriptionPlan sp : subsPlanList){
			
			subsPlan = sp;
			
		}
		
		return subsPlan;
	}
}
	
