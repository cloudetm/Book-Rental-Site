package com.r2r.orderedcart.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.r2r.order.dao.OrderDAO;
import com.r2r.orderedcart.dao.OrderedCartDAO;
import com.r2r.orderedcart.model.OrderedCart;

public class OrderedCartServiceImpl implements OrderedCartService {

	
	private OrderedCartDAO orderedCartDAO;
	
	public void setOrderedCartDAO(OrderedCartDAO orderedCartDAO){
		this.orderedCartDAO = orderedCartDAO;
	}
	
	@Override
	@Transactional
	public void createOrderedCart(List<OrderedCart> oCart) {
		this.orderedCartDAO.createOrderedCart(oCart);

	}

	@Override
	@Transactional
	public List<OrderedCart> getOrderedCartByOrderId(int orderId) {
		return this.orderedCartDAO.getOrderedCartByOrderId(orderId);
	}

}
