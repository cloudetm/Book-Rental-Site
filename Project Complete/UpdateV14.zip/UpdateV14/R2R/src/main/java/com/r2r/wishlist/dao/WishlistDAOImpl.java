package com.r2r.wishlist.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.r2r.regis.model.Customer;
import com.r2r.wishlist.model.Wishlist;


@Repository
public class WishlistDAOImpl implements WishlistDAO {

	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	@Override
	public void addItem(Wishlist w){
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(w);
	}
	
	@Override
	public void deleteItem(Wishlist w){
		Session session = this.sessionFactory.getCurrentSession();
		session.delete(w);
	}
	
	@Override
	public List<Wishlist> getAll(String cust_email){
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "FROM Wishlist W WHERE W.cust_email = :cust_email";
		Query query = session.createQuery(hql);
		query.setParameter("cust_email", cust_email);
		List <Wishlist> wl = query.list();
		return wl;
	}
	
	@Override
	public void removeAll(String cust_email){
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "DELETE FROM Wishlist W WHERE W.cust_email = :cust_email";
		Query query = session.createQuery(hql);
		query.setParameter("cust_email", cust_email);
		query.executeUpdate();
	}
}
