package com.r2r.model;



public class RequestMessage  {
	
	
	private String custEmail;
	private String custPassword;

	public String getCustEmail()
	{
		return custEmail;
	}

	public void setCustEmail(String custEmail)
	{
		this.custEmail = custEmail;
		
	}
	public String getCustPassword()
	{
		return custPassword;
	}

	public void setCustPassword(String custPassword)
	{
		this.custPassword = custPassword;
	}
	

}
