package com.r2r.wishlist.dao;

import java.util.List;

import com.r2r.wishlist.model.Wishlist;

public interface WishlistDAO {

	public void addItem(Wishlist w);
	public void deleteItem(Wishlist w);
	public void removeAll(String cust_email);
	public List<Wishlist> getAll(String cust_email);
}
