package com.r2r.regis.model;

public class CustomerUpdate {
	
	private String custEmail;
	private String custAddress;
	private String custCity;
	private String custState;
	private Long custPincode;
	private Long custMobileNo;
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public String getCustCity() {
		return custCity;
	}
	public void setCustCity(String custCity) {
		this.custCity = custCity;
	}
	public String getCustState() {
		return custState;
	}
	public void setCustState(String custState) {
		this.custState = custState;
	}
	public Long getCustPincode() {
		return custPincode;
	}
	public void setCustPincode(Long custPincode) {
		this.custPincode = custPincode;
	}
	public Long getCustMobileNo() {
		return custMobileNo;
	}
	public void setCustMobileNo(Long custMobileNo) {
		this.custMobileNo = custMobileNo;
	}
	
}
