angular.module("mainModule",[])
.controller("mainController",function($scope,$http)
		{
	 
	 $scope.getEmail='';
	 $scope.getPassword='';
	 
	$scope.getCall=function()
	{

				console.log($scope.getEmail+$scope.getPassword);			
				
				var out ={'email':$scope.getEmail, 'password':$scope.getPassword};
				console.log(out);
	
				
				$http({
			        method  : 'POST',
			        url     : '/login/process',
			        data    : JSON.stringify(out),
			        headers : {'Content-type':'application/json'} // set the headers so angular passing info as form data (not request payload)
			    })
			        .success(function(data) {
			            console.log(data.message);

			            
			                $scope.message = data.message;	
			                $scope.username = data.username;
			            
			        })
			        .error(function (){
			        	alert('in error');
			       });

			};

		});