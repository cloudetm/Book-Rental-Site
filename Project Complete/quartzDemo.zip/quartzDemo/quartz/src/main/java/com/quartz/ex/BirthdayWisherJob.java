package com.quartz.ex;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.mail.MessagingException;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.QuartzJobBean;
 
public class BirthdayWisherJob extends QuartzJobBean
{
  

  
 @Override
 protected void executeInternal(JobExecutionContext context) throws JobExecutionException
 {
  System.out.println("Sending Birthday Wishes... ");
  List<User> usersBornToday = getUsersBornToday();
  for (User user : usersBornToday)
  {
   try
   {
    EmailSender emailSender = new EmailSender();
   
    emailSender.sendEmail(user.getEmail(), "hbd", "Happy B'day");
   
   
   }
   catch (Exception e)
   {
    e.printStackTrace();
   }
  }
 }
  
 private List<User> getUsersBornToday()
 {
  List<User> users = new ArrayList<User>();
  User user1 = new User("abc", "abc@gmail.com", new Date());
  users.add(user1);
  User user2 = new User("xyz", "xyz@gmail.com", new Date());
  users.add(user2);
  return users;
 }
}